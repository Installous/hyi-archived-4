var Scale = "1"; 
var Clock = "12h"; // choose between "12h" or "24h"
var refreshrate = 10; // update interval of weather, in minutes
var IconWeather = "1"; // 1=White, 2=Black
var Icon = 1; // 1=google, 2=safari, 3=reddit, 4=twitter, 5=facebook, 6=instagram
var IconColor = "azure"; 
var TextColor = "azure"; 
var BackgroundColor = "black"; 
var BlurBackground = false; 
var HideBackground = true; 
