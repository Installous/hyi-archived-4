// Configuration Clock //
var Clock = "24h";			
// Choose Between "12h" or "24h"

// Configuration Language //
var Lang = "fr";			
// (fr) for french, (de) for german, (ca) for spanish, (it) for italian, (en) for english.