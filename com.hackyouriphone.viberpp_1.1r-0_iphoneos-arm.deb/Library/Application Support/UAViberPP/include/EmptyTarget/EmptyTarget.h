//
//  EmptyTarget.h
//  EmptyTarget
//
//  Created by Enea Gjoka on 7/3/15.
//
//

#import <Foundation/Foundation.h>

@interface EmptyTarget : NSObject

@end
