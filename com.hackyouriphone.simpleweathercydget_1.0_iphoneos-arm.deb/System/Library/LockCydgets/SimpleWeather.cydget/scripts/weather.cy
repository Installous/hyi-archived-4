/* .cy file should only contain cycript scripts for better performance */
getWeather = function () {
  return [[WeatherPreferences sharedPreferences] localWeatherCity];
};
windDirection = function () {
 return [getWeather() windDirectionAsString:getWeather().Direction];
};
updateWeather = function () {
if(![[CLLocationManager sharedManager] locationServicesEnabled]){
    alert("You must enable Location Services and make sure Weather.app is toggled on.");
}
    WPref = [WeatherPreferences sharedPreferences];
    WLocation = [WeatherLocationManager sharedWeatherLocationManager];
    WCity = [WPref localWeatherCity];
    LUpdate = [TWCLocationUpdater sharedLocationUpdater];
    [WLocation setDelegate:[[CLLocationManager alloc] init]];
    [WLocation setLocationTrackingReady:YES activelyTracking:NO];
    [WLocation setLocationTrackingActive:YES];
    [WPref setLocalWeatherEnabled:YES];
    [LUpdate updateWeatherForLocation:[WLocation location] city:WCity];
    [LUpdate handleCompletionForCity:WCity withUpdateDetail:0];
};