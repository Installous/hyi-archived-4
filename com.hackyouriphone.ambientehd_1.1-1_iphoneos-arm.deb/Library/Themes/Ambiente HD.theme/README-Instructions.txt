Instructions for using Ambiente HD theme for iPhone 4 by Primo.

1. Requirements

	- WinterBoard
	- ***Gridlock (only if you want to use the included Picture widget)
	- ***ColorKeyboard (only if you want to use the included ColorKeyboard theme)
	
	
2. Installation

	- Copy folders "Ambiente HD.theme", "Ambiente HD-Lockscreen.theme" and "Ambiente HD-Widget(1).theme" to "/Library/Themes/" on your device and activate through WinterBoard (make sure "SummerBoard Mode" is "OFF")
	- Copy SetAsWallpaper.png (from "Ambiente HD.theme" folder) to your pictures folder and set it as home and lockscreen wallpaper.
	- If you want to use the SBSettings theme, go to folder "SBSettings/" and copy folder "AmbienteHD" to "/var/mobile/Library/SBSettings/Themes/" on your device and activate the theme in SBSettings
	- If you want to use the ColorKeyboard theme, go to folder "ColorKeyboard/" and copy folder "AmbienteHD" to "/Library/ColorKeyboard/Themes/" on your device and activate the theme in ColorKeyboard
	

3. Configuration

	- Homescreen Weather - open "/Library/Themes/Ambiente HD-Widget(1).theme/configureMe.js" with any text editor and edit whatever you need. RESPRING the device for changes to take effect!
	- Homescreen Picture widget - to change the image, copy your picture to "/Library/Themes/Ambiente HD-Widget(1).theme/Private/" and name it "wall.png" (without the quotes). The picture should be 300x500px or it will be automatically rezised to fit the window.

	- Lockscreen Weather - open "/Library/Themes/Ambiente HD-Lockscreen.theme/configureMe.js" with any text editor and edit whatever you need. RESPRING the device for changes to take effect!
	- Lockscreen Picture widget - to change the image, copy your picture to "/Library/Themes/Ambiente HD-Lockscreen.theme/Private/" and name it "wall.png" (without the quotes). The picture should be 300x500px or it will be automatically rezised to fit the window.
	
	- How to find your location code:
		- Open http://weather.yahoo.com , find your location and click on it;
		- Click on the "RSS" link on the right and look at the browser's address bar. It should say something like "http://weather.yahooapis.com/forecastrss?p=UKXX0085&u=f". The code "UKXX0085" at the end is the location code.
  

4. Support

	- Official ModMyi thread: 
	  http://modmyi.com/forums/iphone-4-new-skins-themes-launches/804454-ambiente-hd-theme-release.html
	  
	- You can also get support by following me on Twitter: www.twitter.com/PrimoTM
	  
	- If you have any suggestions for new icons, UI elements, or anything else, you can post them in the thread.