// The code of your location
var locale = "UKXX0085" //e.g. "USNY0996"

// Set to 'false' if you prefer Farenheit
var isCelsius = true //true|false

// How often the weather is updated
var updateInterval = 10 //Minutes