//var scale = "100";

//var iconSet = "semitrans";

var XML_TEST = false;

var updateFileTimer = "";

var obj = new Array;

var where = "";

var time_to_change_wall;

var dayhour;

var nighthour;

var ampm = false;	

var GMT = 0;



function init() {



updateClock();

setInterval(updateClock, 1000);

updateWeather();

var scale =80;

if ( scale == 50 ){document.getElementById('scaler').style.webkitTransform = 'scale(0.5)';}

if ( scale == 60 ){document.getElementById('scaler').style.webkitTransform = 'scale(0.6)';}

if ( scale == 70 ){document.getElementById('scaler').style.webkitTransform = 'scale(0.7)';} 

if ( scale == 80 ){document.getElementById('scaler').style.webkitTransform = 'scale(0.8)';} 

if ( scale == 90 ){document.getElementById('scaler').style.webkitTransform = 'scale(0.9)';} 

if ( scale == 100 ){document.getElementById('scaler').style.webkitTransform = 'scale(1.0)';}

}





function dealWithWeather(obj) {

var sunriseh = parseInt(obj.sunrise.split(':')[0]) + GMT;

var sunrisem = obj.sunrise.split(':')[1];

var sunseth = parseInt(obj.sunset.split(':')[0]) + GMT;

var sunsetm = obj.sunset.split(':')[1];

dayhour = sunriseh + parseInt(sunrisem)/60;

nighthour = sunseth + parseInt(sunsetm)/60;



if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { where = "night"; } else { where = "day"; }



document.getElementById("Day0Icon").src = "Icon Sets/"+iconSet+"/"+AdjustIcon(obj.icon, where)+".png";



}



function updateClock() {

	var currentTime = new Date();

	var currentHours = currentTime.getHours();

	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();

	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();

	var mil = currentTime.getMilliseconds();

	time_to_change_wall = currentHours + currentMinutes/60;

	

		var mdegree = currentMinutes * 6;

		var mrotate = "rotate(" + mdegree + "deg)";

	$("#minhand").css("-webkit-transform", mrotate);



		var hdegree = currentHours * 30 + (currentMinutes / 2);

		var hrotate = "rotate(" + hdegree + "deg)";

	$("#hourhand").css("-webkit-transform", hrotate);



	if (dayhour != null) {

		if ((time_to_change_wall < dayhour) || (time_to_change_wall >= nighthour)) { var whereTmp = "night";	} else { var whereTmp = "day"; }

		if (whereTmp != where) { dealWithWeather(obj); } // Refresh the weather for day/night condition.

	}

		

}



function updateWeather() {

if (XML_TEST == true) { var url = "widgetweather.xml" } else { var url =  "file:///private/var/mobile/Documents/widgetweather.xml"; }



jQuery.get(url, function(data) {



obj.updatetimestring = $(data).find('updatetimestring').text();



if (updateFileTimer != obj.updatetimestring) {



	$(data).find('currentcondition').each( function() {

		obj.icon = $(this).find('code').text();

		obj.sunset = $(this).find('sunsettime').text();

		obj.sunrise = $(this).find('sunrisetime').text();

		

	});



	updateFileTimer = obj.updatetimestring;

	dealWithWeather(obj);

}

}).fail(function() {

	document.getElementById("xmlupdate").innerHTML = "No XML file !";

});



refreshTimer = setTimeout(updateWeather, 20*1000);

}



function AdjustIcon(icon, whereTmp) {

	switch(whereTmp) {

		case "day":

			if (icon == 27) { icon = 28; }

			if (icon == 29) { icon = 30; }	

			if (icon == 31) { icon = 32; }	

			if (icon == 33) { icon = 34; }

		break;

		case "night":

			if (icon == 28) { icon = 27; }

			if (icon == 30) { icon = 29; }	

			if (icon == 32) { icon = 31; }	

			if (icon == 34) { icon = 33; }

		break;

	}

	return icon;

}