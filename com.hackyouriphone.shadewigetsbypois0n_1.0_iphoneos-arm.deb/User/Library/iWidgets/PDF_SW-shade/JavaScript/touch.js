/* ------Single or DoubleTap By Ian Nicoll ------ */

var doubleTapped = false;
var forecastdisplay = true;
var iOS = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false;
if (iOS == true) { var touchmode = "touchend"; } else { var touchmode = "click"; }

function StartTouch() {
	document.getElementById("forecastContainer").className = "fade-out";
	forecastdisplay = false;
	document.getElementById("touchForecast").addEventListener(touchmode, touchWithNoForecastAtStart, false);
}

function touchWithForecastAtStart(event) {
	if (useDoubleTap == true) {
		if(!doubleTapped) {
			doubleTapped = true;
			setTimeout( function() { doubleTapped = false; }, 500 );
			return false;
		}
	}
    event.preventDefault();
	if (forecastdisplay == false) {
		document.getElementById("forecastContainer").className = "block";
		document.getElementById("CurrentConditionIconContainer").className = "scaleZero";
		forecastdisplay = true;
	} else {
		document.getElementById("forecastContainer").className = "fade-out";	
		document.getElementById("CurrentConditionIconContainer").className = "scaleNormal";	
		forecastdisplay = false;
	}
}

function touchWithNoForecastAtStart(event) {
	if (useDoubleTap == true) {
		if(!doubleTapped) {
			doubleTapped = true;
			setTimeout( function() { doubleTapped = false; }, 500 );
			return false;
		}
	}
    event.preventDefault();
	if (forecastdisplay == false) {
		document.getElementById("intro").style.display = "block";
		document.getElementById("titles").style.display = "block";
		document.getElementById("forecastContainer").className = "fade-in";
		document.getElementById("CurrentConditionIconContainer").className = "scaleZero";
		forecastdisplay = true;
	} else {
		document.getElementById("intro").style.display = "none";
		document.getElementById("titles").style.display = "none";
		document.getElementById("forecastContainer").className = "fade-out";	
		document.getElementById("CurrentConditionIconContainer").className = "scaleNormal";
		forecastdisplay = false;
	}
}
