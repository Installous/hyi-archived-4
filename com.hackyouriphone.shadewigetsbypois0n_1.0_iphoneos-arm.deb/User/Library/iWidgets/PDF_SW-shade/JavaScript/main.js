// WW2_Modders_Base_Widget (simple widget) By Ian Nicoll

// GLOBAL VARIABLES
var updateFileTimer = "";
var updateTimer = 0;
var refreshTimer;
var obj = {};
var where = "";
var filename = "";
var dayOrNight;
var dayhour;
var nighthour;
var current_condition = "";
var UTC = 0;
var GMT = 0;
var iPhoneType = "auto";

// GET THE CURRENT WIDTH & HEIGHT
if (iPhoneType == "auto") {
	if (screen.height == 480) { iPhoneType = "iPh4"; }
	else if (screen.height == 568) { iPhoneType = "iPh5"; }
	else if (screen.height == 667) { iPhoneType = "iPh6"; }
	else { iPhoneType = "iPh6Plus"; }
}

// RESIZE THE BODY
window.addEventListener("load", function() { 
	switch(iPhoneType) {
		case "iPh4":
			document.body.style.width='320px';
    		document.body.style.height='568px'; // Keep at 568px (not 480px).
		break;
		case "iPh5":
			document.body.style.width='320px';
    		document.body.style.height='568px';
		break;
		case "iPh6":
			document.body.style.width='375px';
    		document.body.style.height='667px';
		break;
		case "iPh6Plus":
			document.body.style.width='414px';
    		document.body.style.height='736px';
		break;
	}
}, false);

// WEATHER CONDITIONS
var Conditions = [
	"thunderstorm", // 0 tornado
	"thunderstorm", // 1 tropical storm
	"thunderstorm", // 2 hurricane
	"thunderstorm", // 3 severe thunderstorms
	"thunderstorm", // 4 thunderstorms
    "sleet", // 5 mixed rain and snow
    "sleet", // 6 mixed rain and sleet
    "sleet", // 7 mixed snow and sleet
    "sleet", // 8 freezing drizzle
	"showers", // 9 drizzle
    "sleet", // 10 freezing rain
    "showers", // 11 showers
	"rain", // 12 rain
	"lightsnow", // 13 snow flurries
	"lightsnow", // 14 light snow showers
    "snow", // 15 blowing snow
    "snow", // 16 snow
    "hail", // 17 hail
    "sleet", // 18 sleet
    "fog", // 19 dust
    "fog", // 20 foggy
    "haze", // 21 haze
    "fog", // 22 smoky
	"wind", // 23 blustery
	"wind", // 24 windy
    "frost", // 25 cold
    "cloud", // 26 cloudy
    "mostlycloudy", // 27 mostly cloudy (night)
    "mostlycloudy", // 28 mostly cloudy (day)
    "partlycloudy", // 29 partly cloudy (night)
    "partlycloudy", // 30 partly cloudy (day)
    "clear", // 31 clear (night)
    "clear", // 32 sunny
    "fair", // 33 fair (night)
    "fair", // 34 fair (day)
    "sleet", // 35 mixed rain and hail
    "clear", // 36 hot
	"scattered_thunderstorms", // 37 isolated thunderstorms
	"scattered_thunderstorms", // 38 scattered thunderstorms
	"scattered_thunderstorms", // 39 scattered thunderstorms
	"showers", // 40 scattered showers
	"heavysnow", // 41 heavy snow
	"lightsnow", // 42 scattered snow showers
	"heavysnow", // 43 heavy snow
    "partlycloudy", // 44 partly cloudy
    "thunderstorm", // 45 thundershowers
	"lightsnow", // 46 snow showers
	"thunderstorm", // 47 isolated thundershowers
	"blank"]; // 3200 not available

function init() {
		
	if (location.pathname.indexOf("Widget") != -1) {
		document.body.style.position = "absolute";
	}
	
	StartTouch();
	updateClock();
    setInterval(updateClock, 1000);
	updateWeather();

} // End of init function

function updateClock() {
	currentTime = new Date();
	if (UTC != 0) { currentTime = new Date(currentTime.getTime() + UTC*3600*1000); }
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate();
	dayOrNight = currentHours + currentMinutes/60;
	timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

	if (ampm == false) {
		timeOfDay = "";
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentTimeString = currentHours + ":" + currentMinutes;
	} else {
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentTimeString = currentHours + ":" + currentMinutes + " " + timeOfDay;
	}
	if (showClock == true) {
		if (SecDisplay == true) {
			document.getElementById("hours_minutes_seconds").innerHTML = currentHours + ":" + currentMinutes  + ":" + currentSeconds;
		} else {
			document.getElementById("hours_minutes_seconds").innerHTML = currentHours + ":" + currentMinutes;
		}
		document.getElementById("ampm").innerHTML = timeOfDay;
    } else {
		document.getElementById("clockBG").style.display = 'none';
		if (lang == "ge") {
			document.getElementById("date").innerHTML = days[currentTime.getDay()] + months[currentTime.getMonth()] + currentDate;
		} else {
			document.getElementById("date").innerHTML = days[currentTime.getDay()] + months[currentTime.getMonth()] + currentDate;
		}
	}
	if ((showDate == true) && (showClock == true)) {
		if (lang == "ge") {
			document.getElementById("day").innerHTML = days[currentTime.getDay()];
		} else {
			document.getElementById("day").innerHTML = days[currentTime.getDay()];
		}
		document.getElementById("date").innerHTML = months[currentTime.getMonth()] + currentDate;
	}
} // End of updateClock function

function dealWithWeather(obj) {
	
	// ADDITIONAL INFORMATIONS FOR UNITS
	if (Distance_In_Miles == true) {
		convertD = 0.621371192;
		visibilityunit = "mi.";
		windspeedunit = "mph";
	} else {
		convertD = 1;
		visibilityunit = "km";
		windspeedunit = "km/h";
	}

	if (Inches_Of_Mercury == true) {
		convertP = 33.8638864;
		pressureunit = "inHg";
	} else {
		convertP = 1;
		pressureunit = "mb";
	}
	
	if (obj.celsius == "YES") { var Unit = "C" } else { var Unit = "F" }
	
	var tempUnit = "&#176;" + Unit;
	var tempUnit_HiLo =  "&#176;";
	var tempUnit_Forecast = "&#176;";
	var tempUnit_HiLo = "&#176;";
	
	// SUNRISE & SUNSET
	var sunriseh = parseInt(obj.sunrise.split(':')[0]);
	var sunrisem = obj.sunrise.split(':')[1];
	var sunseth = parseInt(obj.sunset.split(':')[0]);
	var sunsetm = obj.sunset.split(':')[1];
	dayhour = sunriseh + parseInt(sunrisem)/60;
	nighthour = sunseth + parseInt(sunsetm)/60;
		
	if (ampm == false) {
		var sunriseh = ( sunriseh < 10 ? "0" : "" ) + sunriseh;
		var sunseth = ( sunseth < 10 ? "0" : "" ) + sunseth;
		var sunrise = sunriseh + ":" + sunrisem;		
		var sunset = sunseth + ":" + sunsetm;
		} else {
		var timeOfSunset = ( sunseth < 12 ) ? "am" : "pm";
		var timeOfSunrise = ( sunriseh < 12 ) ? "am" : "pm";
		sunriseh = ( sunriseh > 12 ) ? sunriseh - 12 : sunriseh;
		sunriseh = ( sunriseh == 0 ) ? 12 : sunriseh;
		sunseth = ( sunseth > 12 ) ? sunseth - 12 : sunseth;
		sunseth = ( sunseth == 0 ) ? 12 : sunseth;
		var sunrise = sunriseh + ":" + sunrisem + " " + timeOfSunrise;	
		var sunset = sunseth + ":" + sunsetm + " " + timeOfSunset;
	}
		
	document.getElementById("Sunrise").innerHTML = sunrisetext + "<BR>" + sunrise;
	document.getElementById("Sunset").innerHTML = sunsettext + "<BR>" + sunset;
			
	// DAY OR NIGHT ?
	if ((dayOrNight < dayhour) || (dayOrNight >= nighthour)) { where = "night"; } else { where = "day"; }
	
	// CITY INFORMATION
	var cityname = obj.city;
	switch (UseExtraLocation) {
		case "city":
			if ((obj.extraLocCity != null) && (obj.extraLocCity != "") && (typeof(obj.extraLocCity) != "undefined")) { cityname = obj.extraLocCity; }
		break;
		case "neighborhood":
			if ((obj.extraLocNeighborhood != null) && (obj.extraLocNeighborhood != "") && (typeof(obj.extraLocNeighborhood) != "undefined")) { cityname = obj.extraLocNeighborhood; }
			
			else if ((obj.extraLocCity != null) && (obj.extraLocCity != "") && (typeof(obj.extraLocCity) != "undefined")) { cityname = obj.extraLocCity; }
			
			else if ((obj.extraLocCounty != null) && (obj.extraLocCounty != "") && (typeof(obj.extraLocCounty) != "undefined")) { cityname = obj.extraLocCounty; }
		break;
	}

    // IF YOUR CITY NAME IS WRONG, YOU CAN CORRECT IT HERE!
    if ((cityname == "wrongNameHere") || (cityname == "wrongNameHere")) {cityname = "correctNameHere";}
    //===========================================================

	// MAIN INFORMATIONS
	if (obj.offline == false) { document.getElementById("city").className = ""; }
	document.getElementById("city").innerHTML = cityname;
	
	// ADDRESS
	if ((obj.extraLocLine1 == "undefined") || (obj.extraLocLine1 == "null") || (obj.extraLocLine1 == "")) {
		obj.extraLocLine1 = "Address not available!";
		document.getElementById("address").innerHTML = obj.extraLocLine1;
	} else {
		document.getElementById("address").innerHTML = obj.extraLocLine1;    
	}
	
	document.getElementById("CurrentConditionIcon").src = "Icon Sets/"+iconSetForCurrentCondition+"/"+AdjustIcon(obj.code[0], where)+".png";
	$("#low").html(lowtext + '<span style= color:' + tempColor(obj.low[0]) + ';>' + obj.low[0] + tempUnit_HiLo + '</span>');
	$("#high").html(hightext + '<span style= color:' + tempColor(obj.high[0]) + ';>' + obj.high[0] + tempUnit_HiLo + '</span>');
	
	// UVINDEX COLOR XODE
	var uvindexColorCode = "";
	if (obj.UVindex  >= 11) { uvindexColorCode = "#998cff;"; }
	if (obj.UVindex <= 10) { uvindexColorCode = "#ff0000;"; }
	if (obj.UVindex <= 7) { uvindexColorCode = "#ff9000;"; }
	if (obj.UVindex <= 5) { uvindexColorCode = "#f7e400;"; }
	if (obj.UVindex <= 2) { uvindexColorCode = "#4eb400;"; }
	if (where == "night") { uvindexColorCode = "#4eb400;";}
	
	if (obj.UVindex != null && obj.UVindex != "") { document.getElementById("UVindex").innerHTML = UVIndextext + '<span style="color: ' + uvindexColorCode + '">' + ((where == "day") ? obj.UVindex : 0) + '</span>'; }    	// WIND DESCRIPTION	var wind_description = "";	if ((Show_Wind_Description == true) && (Math.round(obj.windspeed) != 0)) { var wind_description = ", " + WindDescription(); }		//DEW POINT	if (obj.dewpt != null && obj.dewpt != "") { document.getElementById("dewpt").innerHTML = Dewpointtext + obj.dewpt + tempUnit_Forecast; }		// TEMP	var tempValue = obj.temp;	document.getElementById("feelslike").innerHTML = feelsliketext + '<span style= color:' + tempColor(obj.realFeel) + ';>' + obj.realFeel + tempUnit + '</span>';	document.getElementById("temp").style.color = tempColor(tempValue);	document.getElementById("temp").innerHTML = tempValue + tempUnit;			// VISIBILITY & HUMIDITY	document.getElementById("visibility").innerHTML = visibilitytext  + " " + Math.round(obj.visibility*convertD) + " " + visibilityunit;	document.getElementById("humidity").innerHTML = humiditytext + obj.humidity + "%";

	document.getElementById("moonDescription").innerHTML = obj.moondesc;
	// WINDSPEED	var windspeed = Math.round(obj.windspeed*convertD);	if (windspeed == 0) {		document.getElementById("windspeed").innerHTML = nowindtext;		document.getElementById("windArrow").style.display = 'none';	} else {		if (WindArrow_Shows_Direction_Wind_Is_Blowing == true) {			document.getElementById("windArrow").innerHTML = "&#x2193;";		} else {			document.getElementById("windArrow").innerHTML = "&#x2191;";		}		document.getElementById("windArrow").style.webkitTransform = "rotateZ(" + obj.direction + "deg)";		document.getElementById("windspeed").innerHTML = windtext + " - " + windspeed + " " + windspeedunit;	}	// PRESSURE (DESACTIVED FOR THE MOMENT, NO PRESSURE STATE IN MY COUNTRY)	if (obj.rising == 0) { document.getElementById("rising").innerHTML = "&larr;&rarr;"; }	else if (obj.rising == 1) { document.getElementById("rising").innerHTML = "&uarr;"; }	else { document.getElementById("rising").innerHTML = "&darr;"; }			if (Inches_Of_Mercury == true) {		var pressure = Math.round(obj.pressure*100/convertP)/100;		document.getElementById("pressure").innerHTML = pressuretext + pressure.toFixed(2) + " " + pressureunit;	} else {		document.getElementById("pressure").innerHTML = pressuretext + Math.round(obj.pressure/convertP) + " " + pressureunit;	}

	// NO SUNNY DESCRIPTION FOR NIGHT CONDITION	if ((obj.code[0] == 32) && (where == "night")) { document.getElementById("description").innerHTML = WeatherDesc[31] + wind_description; }	else if ((obj.code[0] == 34) && (where == "night")) { document.getElementById("description").innerHTML = WeatherDesc[33] + wind_description; }	else { document.getElementById("description").innerHTML = WeatherDesc[obj.code[0]] + wind_description; }		// XML LAST UPDATE
	if ((obj.lastupdate.length > 2) && ((obj.lastupdate[2] == "PM") || (obj.lastupdate[2] == "AM"))) {
		document.getElementById("xmlupdate").innerHTML = lastupdatetext + obj.lastupdate[1].split(":")[0]*1 + ":" + obj.lastupdate[1].split(":")[1] + " " + obj.lastupdate[2].toLowerCase();
		} else {
		document.getElementById("xmlupdate").innerHTML = lastupdatetext + obj.lastupdate[1].split(":")[0] + ":" + obj.lastupdate[1].split(":")[1];
	}

	// DAY FORECAST
	var numberOfDays = numberOfForcastDays -1 +2;
	for (var i=1; i < numberOfDays; i++) { /* TO CHANGE NUMBER OF FORECAST DAYS, CHANGE THE "6" VALUE */
		$("#Day" + i).removeClass();
		if (lang == "ge") {
			$("#Day" + i).html(days[obj.dayofweek[i]-1].substring(0,2));
		} else {
			$("#Day" + i).html(days[obj.dayofweek[i]-1].substring(0,3));
		}
		$("#Day" + i + "Pop").html(obj.pop[i] + "%");
		$("#Day" + i + "Icon").attr("src", "Icon Sets/" + iconSetForForecast+"/" + AdjustIcon(obj.code[i], "day") + ".png");
		if (Hi_Lo_Reversed == false) {
			$("#Day" + i + "HiLo").html('<span style= color:' + tempColor(obj.low[i]) + ';>' + obj.low[i]  +  tempUnit_Forecast + " / " + '<span style= color:' + tempColor(obj.high[i]) + ';>' + obj.high[i] + tempUnit_Forecast) + '</span>';
		} else {
			$("#Day" + i + "HiLo").html('<span style= color:' + tempColor(obj.high[i]) + ';>' + obj.high[i] +  tempUnit_Forecast + " / " + '<span style= color:' + tempColor(obj.low[i]) + ';>' + obj.low[i] + tempUnit_Forecast) + '</span>';		
		}
	}
	for (var i = 1; i<6; i++) {
		document.getElementById("Day" + i + "Icon").style.left = 11 +  17.5*(i-1) + "%";
		document.getElementById("Day" + i + "Pop").style.left = 15 +  17.5*(i-1) + "%";
		document.getElementById("Day" + i).style.left = 7.8 +  17.5*(i-1) + "%";
		document.getElementById("Day" + i + "HiLo").style.left = 8 +  17.5*(i-1) + "%";
	}
	current_condition = Conditions[obj.code[0]];
	
		// WALLPAPER OPTIONS
	switch (Wallpaper_options) {
		case "user":
			document.getElementById("userBackground").style.display = "block";
			document.getElementById("weatherWalls").style.display = "none";	
		break;
		case "weatherWalls":
			document.getElementById("weatherWalls").src = "Images/Wallpapers/" + current_condition + "/" + where + ".jpg";
			document.getElementById("userBackground").style.display = "none";
		break;
		case "none":
			document.getElementById("weatherWalls").style.display = "none";
			document.getElementById("userBackground").style.display = "none";
		break;
	}
} // End of dealWithWeather function

function tempColor(temp) {
	if (obj.celsius == "YES") {
		if (temp <= 8) { var color = "#80d0d0"; }
		else if (temp >= 9 && temp <= 15) { var color = "#fdee00"; }
		else if (temp >= 16 && temp <= 22) { var color = "#7eff00"; }
		else if (temp >= 23 && temp <= 27) { var color = "#ffad11"; }
		else  { var color = "#ff4f32"; }
	} else {
		if (temp <= 46) { var color = "#80d0d0"; }
		else if (temp >= 47 && temp <= 59) { var color = "#fdee00"; }
		else if (temp >= 60 && temp <= 71) { var color = "#7eff00"; }
		else if (temp >= 72 && temp <= 80) { var color = "#ffad11"; }
		else  { var color = "#ff4f32"; }
	}
	return color
}

// WORKAROUND FOR CORRECT ICONS IN ALL SITUATIONS AND TWELVE HOUR FORMAT
function AdjustIcon(icon, whereTmp) {
	switch(whereTmp) {
		case "day":
			if (icon == 27) { icon = 28; }
			if (icon == 29) { icon = 30; }	
			if (icon == 31) { icon = 32; }	
			if (icon == 33) { icon = 34; }
			if (icon == 39) { icon = 38; }
		break;
		case "night":
			if (icon == 28) { icon = 27; }
			if (icon == 30) { icon = 29; }	
			if (icon == 32) { icon = 31; }	
			if (icon == 34) { icon = 33; }
			if (icon == 38) { icon = 39; }
		break;
	}
	return icon;
}

function updateWeather() {
if (iOS == false) { var url = "test_files/widgetweather" + ".xml"; } else { var url = "file:///private/var/mobile/Documents/widgetweather" + ".xml"; }
jQuery.get(url, function(data) {
obj.updatetimestring = $(data).find('updatetimestring').text();

if (updateFileTimer != obj.updatetimestring) {
	obj.high = [];
	obj.low  = [];
	obj.code = [];
	obj.pop = [];	
	obj.dayofweek = [];
	obj.sunset;
	obj.sunrise;
	obj.moondesc;
	obj.UVindex;
	obj.day_direction;
	obj.day_speed;
	obj.day_desc;
	updateFileTimer = obj.updatetimestring;
	obj.lastupdate = updateFileTimer.split(' ');
	
	$(data).find('currentcondition').each( function() {
		obj.city = $(this).find('name').text();
		obj.celsius = $(this).find('celsius').text();
		obj.woeid = $(this).find('woeid').text();	
		obj.temp = $(this).find('temp').text()*1; 
		obj.icon = $(this).find('code').text();
		obj.desc = $(this).find('description').text();
		obj.observationtime = $(this).find('observationtime').text();
		obj.timezone = $(this).find('timezone').text().replace("GMT","")*1;
		obj.moondesc = $(this).find('moondesc').text();
		obj.sunrise = ($(this).find('sunrisetime').text());		
		obj.sunset = ($(this).find('sunsettime').text());
		obj.pressure = $(this).find('pressure').text();
		obj.humidity = $(this).find('humidity').text();	
		obj.rising = $(this).find('rising').text()*1;		
		obj.visibility = $(this).find('visibility').text();
		obj.realFeel = ($(this).find('chill').text() == "") ? obj.temp : $(this).find('chill').text()*1;
		obj.direction = $(this).find('direction').text()*1;
		obj.windspeed = $(this).find('speed').text()*1;
		obj.unitsdistance = $(this).find('unitsdistance').text();
		obj.unitspressure = $(this).find('unitspressure').text();
		obj.unitsspeed = $(this).find('unitsspeed').text();
		obj.unitstemperature = $(this).find('unitstemperature').text();
		obj.latitude = $(this).find('latitude').text()*1;
		obj.longitude = $(this).find('longitude').text()*1;
		obj.extraLocLine1 = $(this).find('extraLocLine1').text();
		obj.extraLocName = $(this).find('extraLocName').text().replace(" ","");
		obj.extraLocCity = $(this).find('extraLocCity').text();
		obj.extraLocNeighborhood = $(this).find('extraLocNeighborhood').text();
		obj.extraLocCounty = $(this).find('extraLocCounty').text();
		obj.extraLocState = $(this).find('extraLocState').text();
		obj.extraLocCountry = $(this).find('extraLocCountry').text();
		obj.extraLocCountryCode = $(this).find('extraLocCountryCode').text();
		obj.extraLocUzip = $(this).find('extraLocUzip').text();
		obj.dewpt = $(this).find('dewpt').text();
		obj.UVindex = $(this).find('uvindex').text();
		Distance_In_Miles = (obj.unitsdistance == "km") ? false : true;
		Inches_Of_Mercury = (obj.unitspressure == "mb") ? false : true;
		
		// CORRECT YOUR HOME ADDRESS HERE
		if (obj.extraLocLine1 == "8 Old Quriyat-Sur Road") { // Type in wrong address exactly as shown on screen
			obj.extraLocLine1 = "6 Old Quriyat-Sur Road"; // Type in what you want it to show
		}
		
	});
	
	$(data).find('settings').each( function() {
		obj.interval = $(this).find('interval').text();
		obj.timehour = $(this).find('timehour').text();
		ampm = (obj.timehour == "24h") ? false : true;	
	});

	// LOOK FOR UTC CORRECTION AND FORCE THE CLOCK TO UPDATE
	UTC = obj.timezone + currentTime.getTimezoneOffset()/60;
	updateClock();
		
	if ((obj.lastupdate.length > 2) && ((obj.lastupdate[2] == "PM") || (obj.lastupdate[2] == "AM"))) {
		updateTimer = new Date([obj.lastupdate[0].split('-')[1], obj.lastupdate[0].split('-')[2], obj.lastupdate[0].split('-')[0]].join('/') + " " + obj.lastupdate[1] + " " + obj.lastupdate[2]);
	} else {
		updateTimer = new Date([obj.lastupdate[0].split('-')[1], obj.lastupdate[0].split('-')[2], obj.lastupdate[0].split('-')[0]].join('/') + " " + obj.lastupdate[1]);
	}

	if ( currentTime.getTime() - UTC*3600*1000 - updateTimer.getTime() > obj.interval*60*1000 ) {
		obj.offline = true;
		document.getElementById("city").className = "FontColorRed";
	} else {
		obj.offline = false;
	}
	
	var i=0;
	$(data).find('day').each( function() {
		obj.high[i] = ($(this).find('high').text() == "") ? "null" : $(this).find('high').text()*1;
		obj.low[i] = $(this).find('low').text()*1;
		obj.code[i] = $(this).find('code').text();
		obj.pop[i] = $(this).find('pop').text();
		obj.dayofweek[i] = $(this).find('dayofweek').text()*1;
		if (i != 0) {
			obj.UVindex[i] = $(this).find('uvindex').text();
		}
		if (updateTimer.getDate() == currentTime.getDate()) {
			if (currentTime.getDay() == obj.dayofweek-1) { obj.daydate = new Date(currentTime.getTime() + (24 * 60 * 60 * 1000 * i)); }
			else { obj.daydate = new Date(currentTime.getTime() + (24 * 60 * 60 * 1000 * (i-1))); }
		} else {
			if (updateTimer.getDay() == obj.dayofweek-1) { obj.daydate = new Date(updateTimer.getTime() + (24 * 60 * 60 * 1000 * i)); }
			else { obj.daydate = new Date(updateTimer.getTime() + (24 * 60 * 60 * 1000 * (i-1))); }			
		}
		i++;
	});
	
	// WORKAROUND FOR NULL TEMP
	if (obj.high[0] == "null") { obj.high[0] = "--"; }
		
	// WORKAROUND FOR CURRENT CODE IS NULL
	if (obj.icon == "" || obj.icon == 3200) {
	}

	// FOR LIVE FORECAST VIEW
	obj.code[0] = obj.icon;
	//obj.day_desc = obj.desc;
	
	if (obj.extraLocName != "") {
		obj.latitude = obj.extraLocName.split(",")[0]*1;
		obj.longitude = obj.extraLocName.split(",")[1]*1;
	}
	
	// WEATHER CONDITION TEST (MUST BE COMMENTED-OUT FOR NOLMAL USE)
	//obj.code[0] = 23;

	dealWithWeather(obj);

} else {

	// CHECK IF ONLINE OR OFFLINE
	if ( currentTime.getTime() - UTC*3600*1000 - updateTimer.getTime() > obj.interval*60*1000 ) {
		obj.offline = true;
		document.getElementById("city").className = "FontColorRed";
	}
} // End of updateWeather function

}).fail(function() {
	document.getElementById("description").innerHTML = "No widgetweather.xml file!";
});
	// REINITIALIZE THE TIMER
	clearTimeout(refreshTimer); 
	refreshTimer = setTimeout(updateWeather, 30*1000);
}
function dayofweektonumber(dayofweek) {
	switch (dayofweek) {
		case "Sun": { return 1; }
		case "Mon": { return 2; }
		case "Tue":	{ return 3; }
		case "Wed":	{ return 4; }
		case "Thu":	{ return 5; }
		case "Fri":	{ return 6; }
		case "Sat":	{ return 7; }
	}
}
window.onload = init;