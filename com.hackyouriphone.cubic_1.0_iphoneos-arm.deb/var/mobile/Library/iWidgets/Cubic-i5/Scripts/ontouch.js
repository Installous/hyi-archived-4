function ontouch(el, callback){
 
	var touchsurface = el,
	dir,
	swipeType,
	startX,
	startY,
	distX,
	distY,
	coordX,
	coordY,
	threshold = 45,
	restraint = 150,
	allowedTime = 175,
	elapsedTime,
	startTime,
	handletouch = callback || function(evt, dir, phase, swipetype, xCoordinate, yCoordinate, distance, tap){}

	touchsurface.addEventListener('touchstart', function(e){
		var touchobj = e.changedTouches[0]
		dir = 'none'
		swipeType = 'none'
		dist = 0
		distX = startX = touchobj.pageX
		distY = startY = touchobj.pageY
		startTime = new Date().getTime()
		handletouch(e, 'none', 'start', swipeType, startX, startY, 0, 'no')

	}, false)

	touchsurface.addEventListener('touchmove', function(e){
		var touchobj = e.changedTouches[0]
		elapsedTime = new Date().getTime() - startTime
		distX = touchobj.pageX - startX 
		distY = touchobj.pageY - startY 
		coordX = touchobj.pageX
		coordY = touchobj.pageY
		if (Math.abs(distX) > Math.abs(distY)){
			dir = (distX < 0)? 'left' : 'right'
			handletouch(e, dir, 'move', swipeType, coordX, coordY, distX, 'no')
		}
		else{
			dir = (distY < 0)? 'up' : 'down'
			handletouch(e, dir, 'move', swipeType, coordX, coordY, distY, 'no')
		}
	}, false)

	touchsurface.addEventListener('touchend', function(e){
		var touchobj = e.changedTouches[0]
		elapsedTime = new Date().getTime() - startTime
		if (elapsedTime <= allowedTime){
			if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint){
				swipeType = dir
			}
			else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint){
				swipeType = dir
			}
		}
		handletouch(e, dir, 'end', swipeType, coordX, coordY, (dir =='left' || dir =='right')? distX : distY, (distX === startX && distY === startY)? 'yes' : 'no')
	}, false)
	
	touchsurface.addEventListener('touchcancel', function(e){
		var touchobj = e.changedTouches[0]
		elapsedTime = new Date().getTime() - startTime
		if (elapsedTime <= allowedTime){
			if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint){
				swipeType = dir
			}
			else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint){
				swipeType = dir
			}
		}
		handletouch(e, dir, 'cancel', swipeType, coordX, coordY, (dir =='left' || dir =='right')? distX : distY, (distX === startX && distY === startY)? 'yes' : 'no')
	}, false)
	
	touchsurface.addEventListener('touchleave', function(e){
		var touchobj = e.changedTouches[0]
		elapsedTime = new Date().getTime() - startTime
		if (elapsedTime <= allowedTime){
			if (Math.abs(distX) >= threshold && Math.abs(distY) <= restraint){
				swipeType = dir
			}
			else if (Math.abs(distY) >= threshold && Math.abs(distX) <= restraint){
				swipeType = dir
			}
		}
		handletouch(e, dir, 'leave', swipeType, coordX, coordY, (dir =='left' || dir =='right')? distX : distY, (distX === startX && distY === startY)? 'yes' : 'no')
	}, false)
}