/********************
 * Stratnik widget  *
 ********************/
window.onload = function () {  
    startTimer();
}
/*Digital clock*/
function updateClock () {
	var currentTime = new Date ();
	var currentHours = currentTime.getHours ();
	var currentMinutes = currentTime.getMinutes ();
	var currentSeconds = currentTime.getSeconds ();
	timeOfDay = ( currentHours < 12 ) ? "am" : "pm";
	if (twentyfourhrs  == true) {
	 timeOfDay = "";  
	 currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours; 
	 currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	 currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
	 var currentTimeString = currentHours + currentMinutes;    
	} else {
	 currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	 currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	 currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	 currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	 currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;
	 var currentTimeString = currentHours + ":" + currentMinutes;
	}
	if (AnalogClock == true) {
     document.getElementById("Clock").html=' ';
	}else{
     document.getElementById("hour").firstChild.nodeValue = currentHours+" : ";
     document.getElementById("min").firstChild.nodeValue = currentMinutes+" ";
     document.getElementById("sec").firstChild.nodeValue = ": "+currentSeconds;
     document.getElementById("ampm").firstChild.nodeValue = " "+timeOfDay;
     if (SecDisplay == false) {  
     document.getElementById("sec").style.display='none';}
	}
}/*end Digital clock*/
/*calendar*/
 function calendarDate ( ) {	   
   var month = new Array("01","02","03","04","05","06","07","08","09","10","11","12");
   var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
   var currentDate = new Date()
   var date = currentDate.getDate() < 10 ? '0' + currentDate.getDate() : currentDate.getDate();
   var month = month[currentDate.getMonth()];
   var days = days[currentDate.getDay()].toUpperCase();
   var year = currentDate.getYear()	
   if (year < 1000)
	   year+= 1900;
   if (year==101)
	   year=2001;
   document.getElementById("rotocal").innerHTML = days+", "+date+". "+month;
	if (AnalogClock == false) {    
	document.getElementById("calendarD").innerHTML = month+". "+days+", "+date+". "+year; 
	document.getElementById("calendar").style.display='none';
	document.getElementById("rotocal").style.display='none';
	}     
	if (SecDisplay == false) {	  
    document.getElementById("calendar").innerHTML = days;
	 }
 }/*end calendar*/
 /*Analog clock*/
function getTime() {
	var ret = new Array()
	var now = new Date()
	hTime = new Date().getHours();
	mTime = new Date().getMinutes();
	sTime = new Date().getSeconds();
	dsTime = Math.floor(now.getMilliseconds()/1000)
	return [hTime,mTime,sTime,dsTime]
}
function movement() {
	data =getTime()
	hNum =data[0]
	mNum =data[1]
	sNum =data[2] < 1 ? data[3] : data[2]+''+(data[3])
	if (AnalogClock == false) {
	 a_clock.style.display='none';
	 ahour.style.display='none'; 
	 amin.style.display='none';
     asec.style.display='none';
	}else{
	if (twentyfourhrs == true) {
	hangle =30/2*hNum + (mNum/4)/2;
	document.getElementById("face").src="images/body24.png";
	} else {
	hangle =30*hNum + mNum/2;	
	if (clockFace == "classicNum") {
      document.getElementById("face").src="images/body12.png";}
	if (clockFace == "oldNum"){	      
      document.getElementById("face").src="images/bodyOld12.png";}
	if (clockFace == "noNum"){	   
      document.getElementById("face").src="images/bodyclear.png";}
	}
	mangle =6*mNum+sNum/100  
	sangle =sNum/10*6
     var hrotate = "rotate(" + hangle + "deg)";
     var mrotate = "rotate(" + mangle + "deg)";
     var srotate = "rotate(" + sangle + "deg)";
	 ahour.style.webkitTransform = hrotate;
	 amin.style.webkitTransform = mrotate;
    if (SecDisplay == false) {
      asec.style.display='none';
    } else {
	  asec.style.webkitTransform = srotate;
    }
  }	 
}/*end Analog clock*/
function startTimer(){
    timer = setInterval("movement();", 100);
    updateClock();
    setInterval("updateClock();", 1000);
    calendarDate();
    setInterval("calendarDate();", 1000);
}
function hasClassName(inElement, inClassName){
	var regExp = new RegExp('(?:^|\\s+)' + inClassName + '(?:\\s+|$)');
	return regExp.test(inElement.className);
    }
    function addClassName(inElement, inClassName){
	if (!hasClassName(inElement, inClassName))
	    inElement.className = [inElement.className, inClassName].join(' ');
    }
    function removeClassName(inElement, inClassName){
	if (hasClassName(inElement, inClassName)) {
	    var regExp = new RegExp('(?:^|\\s+)' + inClassName + '(?:\\s+|$)', 'g');
	    var curClasses = inElement.className;
	    inElement.className = curClasses.replace(regExp, ' ');
	}
    }
    function toggleClassName(inElement, inClassName){
	if (hasClassName(inElement, inClassName))
	    removeClassName(inElement, inClassName);
	else
	    addClassName(inElement, inClassName);
    }
    function toggleShape(){
      var shape = document.getElementById('shape');
      if (hasClassName(shape, 'ring')) {
	removeClassName(shape, 'ring');
	addClassName(shape, 'hidden');
      } else {
	removeClassName(shape, 'hidden');
	addClassName(shape, 'ring');
      }      
      // Move the ring back in Z so it's not so in-your-face.
      var stage = document.getElementById('stage');
      if (hasClassName(shape, 'ring')) {
	stage.style.webkitTransform = 'translateZ(-200px) translateX(-12px) translateY(-24px)';
    Timewidget.style.display='none';
    base.style.display='block';    
    baseL.style.display='block';   
     } else {
      if (hasClassName(shape, 'hidden'))
	stage.style.webkitTransform = '';
    Timewidget.style.display='block';
    base.style.display='none';
    baseL.style.display='none';
	baseL.style.webkitAnimationName = "info";
    baseL.style.webkitAnimationDuration = "100ms";
    }
    }	 
    function toggleBackfaces(){
      var backfacesVisible = document.getElementById('backfaces');
      var shape = document.getElementById('shape');
      if (backfacesVisible)
	addClassName(shape, 'backfaces');
      else
	removeClassName(shape, 'backfaces');
    }
/****************************
 *  GetLocation_Weather     *
 *  Author : Vivek Thakur   *
 *  Date   : 25 Feb 2012    *
 *  ----------------------  *
 *  Modified by Stratnik    *
 ****************************/
var prevlatitude = "";
var prevlongitude = "";
var woeid;
var city;
var neighborhood;
var county;
var LocCode;
var textLat;
var textLong;
var state;
var neigh_lat_long;
function UpdateLocation() {  
jQuery.get('/private/var/mobile/Documents/myLocation.txt', function(appdata){
	var myvar = appdata;
	var substr = appdata.split('\n');
	var templatitude=(substr[0]).split('=');
	var templongitude=(substr[1]).split('=');
	var latitude = $.trim(templatitude[1]);
	var longitude = $.trim(templongitude[1]);
	var Yahooappid =""
	    if (prevlatitude != latitude || prevlongitude != longitude) {
	    var url = "http://where.yahooapis.com/geocode?location=" + latitude + "+" + longitude + "&gflags=R&flags=J"
		    $.getJSON(url, function(data) {
			woeid = data.ResultSet.Results[0].woeid;
			city = data.ResultSet.Results[0].city;
			county = data.ResultSet.Results[0].county;
			neighborhood = data.ResultSet.Results[0].neighborhood;
			state = data.ResultSet.Results[0].state;
			if (city != "") {		    
			$("#cityname").text(city);}
			else {
	    $("#cityname").text(county);}		   
			if (latitude < 0) {
			textLat = Math.round(latitude*100)/100 + "\u00B0" + "S";}
			else if (latitude > 0){
			textLat = Math.round(latitude*100)/100 + "\u00B0" + "N";}
			else {
			textLat = Math.round(latitude*100)/100 + "\u00B0";} 
			if (longitude < 0) {
			textLong = Math.round(longitude*100)/100 + "\u00B0" + "W";}
			else if (longitude > 0) {
			textLong = Math.round(longitude*100)/100 + "\u00B0" + "E";}
			else {
			textLong = Math.round(longitude*100)/100 + "\u00B0";}				
			if (neighborhood != "") {
			neigh_lat_long = neighborhood;}
			else {
			neigh_lat_long = state;}	       
		if (coordinate == true) {	   
			$("#latlong").text("["+textLat + " | " +textLong+"]");
		    } else {	$("#neighborhoodname").text(neigh_lat_long);}		      
			prevlatitude = latitude;
			prevlongitude = longitude;										
			GetWeather(woeid); setInterval('GetWeather(woeid)', 1000*20*60 );					
		    });
	    }	
	});	
}
var XMLHttpFactories = [
    function () {
	xhr = new XMLHttpRequest(); xhr.overrideMimeType('text/xml'); 
	return xhr;},
    function(){return new ActiveXObject("Msxml2.XMLHTTP")},
    function(){return new ActiveXObject("Msxml3.XMLHTTP")},
    function(){return new ActiveXObject("Microsoft.XMLHTTP")}
];
    function getXmlHttpRequest() {
    var xmlhttp = false;
    for (var i=0;i<XMLHttpFactories.length;i++) {
    try {xmlhttp = XMLHttpFactories[i]();}
    catch (e) {continue;}
    break;}
    return xmlhttp;
  }
function writeResults() {
	if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
	var response = xmlhttp.responseXML;
	var effectiveRoot = findChild(findChild(response, "rss"), "channel");
	var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
	var humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
	var visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");
	var visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
	var pressure = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("pressure");
	var pressureunit = findChild(effectiveRoot, "yweather:units").getAttribute("pressure");
	var winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
	var windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");
	var windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");
	var chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");	   
	var temp = conditionTag.getAttribute("temp");
	var text = conditionTag.getAttribute("text");
	var code = conditionTag.getAttribute("code");
	var HighLowTag = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
	var high = HighLowTag.getAttribute("high");
	var low = HighLowTag.getAttribute("low");
	var day = HighLowTag.getAttribute("day");    
	var currentTime = new Date ( );
     var currentHours = currentTime.getHours ( );
	 var currentMinutes = currentTime.getMinutes ( );
	if (twentyfourhrs == true) {
	 currentHours = ( currentHours < 12 ? "" : "" ) + currentHours; 
	 currentMinutes = ( currentMinutes < 12 ? "" : "" ) + currentMinutes;
	 currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	 currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;
	}else{
	 currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	 currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	 currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;}
	var update=currentHours + ":" + currentMinutes; 	
	var SunRiseSet = findChild(effectiveRoot, "yweather:astronomy");
	if (twentyfourhrs == true) {
	var SunRise = SunRiseSet.getAttribute("sunrise");
	SunRise = SunRise.split(' ')[0]
	var MySunRise = SunRise.split(' ')[0]
	var sunrisehr = SunRise.split(':')[0]*1
	var sunrisemin = SunRise.split(':')[1]
	var SunSet = SunRiseSet.getAttribute("sunset");
	SunSet = SunSet.split(' ')[0]
	var MySunSet = SunSet.split(' ')[0]
	var sunsethr = SunSet.split(':')[0]*1+12
	var sunsetmin = SunSet.split(':')[1]	
	}else{	
	var SunRise = SunRiseSet.getAttribute("sunrise");
	SunRise = SunRise.split(' ')[0]
	var MySunRise = SunRise.split(' ')[0]
	var sunrisehr = SunRise.split(':')[0]*1
	var sunrisemin = SunRise.split(':')[1]
	var SunSet = SunRiseSet.getAttribute("sunset");
	SunSet = SunSet.split(' ')[0]
	var MySunSet = SunSet.split(' ')[0]
	var sunsethr = SunSet.split(':')[0]*1
	var sunsetmin = SunSet.split(':')[1]}
	var SunRise = SunRiseSet.getAttribute("sunrise");
	var SunSet = SunRiseSet.getAttribute("sunset"); 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	if	(currentHours > 12 ) {
	currentHours = currentHours -12;
	currentTimeNow = currentHours + ":" + currentMinutes + " PM";}
	else if (currentHours == 0 ) {
	currentHours = 12;
	currentTimeNow = currentHours + ":" + currentMinutes + " AM";}	
	else if (currentHours == 12 ) {
	currentTimeNow = currentHours + ":" + currentMinutes + " PM";}
	else {
	currentTimeNow = currentHours + ":" + currentMinutes + " AM"; }
	currentTimeNow = new Date("1/1/2012 " + currentTimeNow);
	var SunR =  new Date("1/1/2012 " + SunRise);
	var SunS =  new Date("1/1/2012 " + SunSet);
	var iconfix;
	if ((currentTimeNow>SunR) && (currentTimeNow<SunS)) {
		//day
		iconfix = "d";}
	else {
		//night
		iconfix = "n"; }
    $("#weathertext").text(text);
	$("#daylight").text("Daylight : "+"0" + sunrisehr + ":" + sunrisemin + " - " +sunsethr + ":" + sunsetmin + "");
	$("#highlowtemp").text("H: " + high + "\u00B0" + " " + "L: " + low + "\u00B0");
	$("#temp").text(temp +tempUnit+ "\u00B0");
	$("#RealFeel").text("Feels like: " +chill +tempUnit+ "\u00B0");
	$('#humidity').text("Humidity: " + humidity + "%");
	$('#visibility').text("Visibility: " + visibility + visibilityunit);
	$('#pressure').text("Pressure: " + pressure + pressureunit);
	direction = parseFloat(winddir);
	if (direction <= 360) winddir = "N";
    if (direction < 348.75) winddir = "N-NW"; 
    if (direction < 326.25) winddir = "NW"; 
    if (direction < 303.75) winddir = "W-NW";
    if (direction < 281.25) winddir = "W";		
    if (direction < 258.75) winddir = "W-SW"; 
    if (direction < 236.25) winddir = "SW";
    if (direction < 213.75) winddir = "S-SW"; 
    if (direction < 191.25) winddir = "S";		
    if (direction < 168.75) winddir = "S-SE";
    if (direction < 146.25) winddir = "SE"; 
    if (direction < 123.75) winddir = "E-SE"; 
    if (direction < 101.25) winddir = "E";		
    if (direction < 78.75) winddir = "E-NE";		
    if (direction < 56.25) winddir = "NE";
    if (direction < 33.75) winddir = "N-NE";		
    if (direction < 11.25) winddir = "N";
    if (direction == 0) winddir = "No wind";			
    if (direction == 0) {		     
	$('#wind').text("Wind : " + winddir); 
	} else {
	$('#wind').text("Wind : " + winddir + " | " + Math.round(windspeed) + " " + windunit);}
	$('#lastupdate').text("Last update: " + update);
	if (weatherimg	== "plastic") {
	var imgsrc = "<img id=\"theImg\" src=\"Icons/plastic/" + code + iconfix + ".png\"/>";}
	if (weatherimg	== "IO") {
	var imgsrc = "<img id=\"theImg\" src=\"Icons/IO/" + code + iconfix + ".png\" />";}
	if (weatherimg	== "stardock") {
	var imgsrc = "<img id=\"theImg\" src=\"Icons/stardock/" + code + iconfix + ".png\"/>";}
	$('#weathericon').html(imgsrc);
     if (AnalogClock == false){
	$("#mycity").text(city);      
	$("#desc").text(text); 
	$("#mytemp").text(temp +tempUnit+ "\u00B0");}	   
    }
}
    function GetWeather(LocCode) {
	if (tempUnit == "f"){
	 tempUnit = 'f' 
    }else{
	 tempUnit = 'c'
	}
	var url="http://weather.yahooapis.com/forecastrss?u="+tempUnit+"&w="+LocCode;	 
    xmlhttp = getXmlHttpRequest();
	   if (xmlhttp) {
	   url = url;
	   xmlhttp.open('GET', url, true);
	   xmlhttp.onreadystatechange = writeResults;
	   xmlhttp.send(null);
	   }
    }
function findChild (element, nodeName){
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling){
		if (child.nodeName == nodeName)
			return child;
	}	
	return null;
}