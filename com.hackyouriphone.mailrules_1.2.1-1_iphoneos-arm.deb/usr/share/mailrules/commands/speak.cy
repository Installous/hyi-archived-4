#!/usr/bin/env cycript

subject = system.args[0];
senderName = system.args[1];

speech = 'New mail from ' + senderName + ':  ' + subject;

[[NSBundle bundleWithPath:'/System/Library/PrivateFrameworks/VoiceServices.framework'] load];
[[new VSSpeechSynthesizer init] startSpeakingString:speech];
new Functor(dlsym(RTLD_DEFAULT, 'sleep'), 'ii').apply(null, [20]);
