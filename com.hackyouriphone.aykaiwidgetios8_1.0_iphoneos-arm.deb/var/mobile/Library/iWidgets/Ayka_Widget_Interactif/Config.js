/*
Configuration here !
Done by Dacal - Modified by Schnedi // DO NOT remove this line  //
For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)
*/

var iconSet = "Climacons";		// Do not Modify.

var ChangeClick = true;         // Do not Modify.

/*
Options below are for specific situations.
*/

var UseCityGPS = false;        // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;    // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).