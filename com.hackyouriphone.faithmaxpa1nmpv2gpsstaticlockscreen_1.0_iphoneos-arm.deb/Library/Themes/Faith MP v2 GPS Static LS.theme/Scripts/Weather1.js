var prevlatitude = "";

var prevlongitude = "";

var zip;

var city;

var neighborhood;

var county;

var LocCode;

var textLat;

var textLong;

var state;

var neigh_lat_long;

	 function UpdateLocation() {  

		jQuery.get('../../../../var/mobile/Documents/myLocation.txt', function(appdata) {

			var myvar = appdata;

			var substr = appdata.split('\n');

			var templatitude=(substr[0]).split('=');

			var templongitude=(substr[1]).split('=');

			var latitude = $.trim(templatitude[1]);

			var longitude = $.trim(templongitude[1]);

			var Yahooappid =""



			if (prevlatitude != latitude || prevlongitude != longitude) {

				var url = "http://where.yahooapis.com/geocode?location=" + latitude + "+" + longitude + "&gflags=R&flags=J"

				$.getJSON(url, function(data) {

					woeid = data.ResultSet.Results[0].woeid;

					city = data.ResultSet.Results[0].city;

					county = data.ResultSet.Results[0].county;

					neighborhood = data.ResultSet.Results[0].neighborhood;

					state = data.ResultSet.Results[0].state;

					if (city != "") {

						$("#cityname").text(city);

					}

					else {

						$("#cityname").text(county);

					}

					if (latitude < 0) {

					 textLat = Math.round(latitude*100)/100 + "\u00B0" + "S";

					}

					 else if (latitude > 0){

						textLat = Math.round(latitude*100)/100 + "\u00B0" + "N";

					 }

					 else {

						textLat = Math.round(latitude*100)/100 + "\u00B0";

					 }

					 if (longitude < 0) {

						textLong = Math.round(longitude*100)/100 + "\u00B0" + "W";

					}

					else if (longitude > 0) {

						textLong = Math.round(longitude*100)/100 + "\u00B0" + "E";

					}

					else {

						textLong = Math.round(longitude*100)/100 + "\u00B0";

					 }

					if (neighborhood != "") {

						neigh_lat_long = neighborhood;

					}

					else {

						neigh_lat_long = state;

					}

					$("#latlong").text(textLat + " " + textLong);

					$("#neighborhoodname").text(neigh_lat_long);

					prevlatitude = latitude;

					prevlongitude = longitude;

					GetWeather(woeid); setInterval('GetWeather(woeid)', 1000*20*60 );

				});

			}	

		});	

	}



var XMLHttpFactories = [

    function () {

	xhr = new XMLHttpRequest(); xhr.overrideMimeType('text/xml'); 

		return xhr;

    },

    function () {return new ActiveXObject("Msxml2.XMLHTTP")},

    function () {return new ActiveXObject("Msxml3.XMLHTTP")},

    function () {return new ActiveXObject("Microsoft.XMLHTTP")}

  ];



  function getXmlHttpRequest() {

    var xmlhttp = false;

    for (var i=0;i<XMLHttpFactories.length;i++) {

      try {

	xmlhttp = XMLHttpFactories[i]();

      }

      catch (e) {

	continue;

      }

      break;

    }

    return xmlhttp;

  }



    function writeResults() {

		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

	       var response = xmlhttp.responseXML;

		var effectiveRoot = findChild(findChild(response, "rss"), "channel");

		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");

		var temp = conditionTag.getAttribute("temp");

		var text = conditionTag.getAttribute("text");

		var code = conditionTag.getAttribute("code");

		var HighLowTag = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");

		var high = HighLowTag.getAttribute("high");

		var low = HighLowTag.getAttribute("low");

		var day = HighLowTag.getAttribute("day");

		var SunRiseSet = findChild(effectiveRoot, "yweather:astronomy");

		var SunRise = SunRiseSet.getAttribute("sunrise");

		var SunSet = SunRiseSet.getAttribute("sunset");

		var currentTime = new Date();

		var currentHours = currentTime.getHours();

		var currentMinutes = currentTime.getMinutes();

		if	(currentHours > 12 ) {

			currentHours = currentHours -12;

			currentTimeNow = currentHours + ":" + currentMinutes + " PM";

			}

		else if (currentHours == 0 ) {

			currentHours = 12;

			currentTimeNow = currentHours + ":" + currentMinutes + " AM";

			}	

		else if (currentHours == 12 ) {

			currentTimeNow = currentHours + ":" + currentMinutes + " PM";

			}

		else {

			currentTimeNow = currentHours + ":" + currentMinutes + " AM";

		}

		currentTimeNow = new Date("1/1/2012 " + currentTimeNow);

		var SunR =  new Date("1/1/2012 " + SunRise);

		var SunS =  new Date("1/1/2012 " + SunSet);

		var iconfix;

		if ((currentTimeNow>SunR) && (currentTimeNow<SunS)) {

			//day

			iconfix = "d";

		 }

		 else {

			//night

			iconfix = "n";

		 }



if (German == true){

if (code == 0) {text="Tornado";}

else if (code == 1 ) {text= "Tropensturm";} 

else if (code == 2 ) {text= "Hurrikan";} 

else if (code == 3 ) {text= "Starkes Gewitter";} 

else if (code == 4 ) {text= "Gewitter";} 

else if (code == 5 ) {text= "Schneeregen";} 

else if (code == 6 ) {text= "Graupel";} 

else if (code == 7 ) {text= "Schneematch";} 

else if (code == 8 ) {text= "Eisspr�hregen";} 

else if (code == 9 ) {text= "Spr�hregen";} 

else if (code == 10 ) {text= "Eisregen";} 

else if (code == 11 ) {text= "Schauer";} 

else if (code == 12 ) {text= "Schauer";} 

else if (code == 13 ) {text= "Schneeflocken";} 

else if (code == 14 ) {text= "Schneeschauer";} 

else if (code == 15 ) {text= "Schneetreiben";} 

else if (code == 16 ) {text= "Schnee";} 

else if (code == 17 ) {text= "Hagel";} 

else if (code == 18 ) {text= "Schneeregen";} 

else if (code == 19 ) {text= "Staub";} 

else if (code == 20 ) {text= "Nebel";}

else if (code == 21 ) {text= "Dunst";} 

else if (code == 22 ) {text= "Rauchig";} 

else if (code == 23 ) {text= "St�rmig";} 

else if (code == 24 ) {text= "Windig";} 

else if (code == 25 ) {text= "Kalt";} 

else if (code == 26 ) {text= "Bew�lkt";} 

else if (code == 27 ) {text= "Stark bew�lkt";} 

else if (code == 28 ) {text= "Stark bew�lkt";} 

else if (code == 29 ) {text= "Etwas bew�lkt";} 

else if (code == 30 ) {text= "Etwas bew�lkt";}

else if (code == 31 ) {text= "Wolkenfrei";} 

else if (code == 32 ) {text= "Sonnig";} 

else if (code == 33 ) {text= "Sch�n";} 

else if (code == 34 ) {text= "Sch�n";} 

else if (code == 35 ) {text= "Hagelregen";} 

else if (code == 36 ) {text= "Hei�";} 

else if (code == 37 ) {text= "Kleine Gwitter";} 

else if (code == 38 ) {text= "Kleine Gwitter";} 

else if (code == 39 ) {text= "Kleine Gwitter";} 

else if (code == 40 ) {text= "Kleine Schauer";}

else if (code == 41 ) {text= "Dicker Schnee";} 

else if (code == 42 ) {text= "Schneeschauer";} 

else if (code == 43 ) {text= "Dicker Schnee";} 

else if (code == 44 ) {text= "Etwas bew�lkt";} 

else if (code == 45 ) {text= "Gewitterschauer";} 

else if (code == 46 ) {text= "Schneeschauer";} 

else if (code == 47 ) {text= "Kleine Gwitter";} 

else {text="Keine Angaben";}

}



if (Spanish == true){

if (code == 0) {text="Tornado";}

else if (code == 1 ) {text= "Tormenta sropical";} 

else if (code == 2 ) {text= "Huracan";} 

else if (code == 3 ) {text= "Tormentas severas";} 

else if (code == 4 ) {text= "Tormentas de truenos";} 

else if (code == 5 ) {text= "Lluvia y nieve";} 

else if (code == 6 ) {text= "Lluvia y aguanieve";} 

else if (code == 7 ) {text= "Tormenta helada";} 

else if (code == 8 ) {text= "Llovizna helada";} 

else if (code == 9 ) {text= "Llovizna";} 

else if (code == 10 ) {text= "Lluvia helada";} 

else if (code == 11 ) {text= "Chubascos";} 

else if (code == 12 ) {text= "Chubascos";} 

else if (code == 13 ) {text= "Corrientes de nieve";} 

else if (code == 14 ) {text= "Lluvias ligeras de nieve";} 

else if (code == 15 ) {text= "Viento con nieve";} 

else if (code == 16 ) {text= "Nieve";} 

else if (code == 17 ) {text= "Granizo";} 

else if (code == 18 ) {text= "Aguanieve";} 

else if (code == 19 ) {text= "Polvo";} 

else if (code == 20 ) {text= "Bruma";}

else if (code == 21 ) {text= "Neblina";} 

else if (code == 22 ) {text= "Humoso";} 

else if (code == 23 ) {text= "Tempestuoso";} 

else if (code == 24 ) {text= "Ventoso";} 

else if (code == 25 ) {text= "Frio";} 

else if (code == 26 ) {text= "Nublado";} 

else if (code == 27 ) {text= "Muy nublado";} 

else if (code == 28 ) {text= "Muy nublado";} 

else if (code == 29 ) {text= "Parc. nublado";} 

else if (code == 30 ) {text= "Parc. nublado";}

else if (code == 31 ) {text= "Despejado";} 

else if (code == 32 ) {text= "Soleado";} 

else if (code == 33 ) {text= "Despejado";} 

else if (code == 34 ) {text= "Despejado";} 

else if (code == 35 ) {text= "Lluvia y granizo";} 

else if (code == 36 ) {text= "Calor";} 

else if (code == 37 ) {text= "Tormentas aisladas";} 

else if (code == 38 ) {text= "Tormentas dispersas";} 

else if (code == 39 ) {text= "Tormentas dispersas";} 

else if (code == 40 ) {text= "Chubascos dispersos";}

else if (code == 41 ) {text= "Mucha nieve";} 

else if (code == 42 ) {text= "Lluvias de nieve dispersas";} 

else if (code == 43 ) {text= "Mucha nieve";} 

else if (code == 44 ) {text= "May. nublado";} 

else if (code == 45 ) {text= "Tormentas de truenos";} 

else if (code == 46 ) {text= "lluvias de nieve";} 

else if (code == 47 ) {text= "Tormentas aisladas";} 

else {text="No disponible";}

}



		$("#weathertext").text(text);

	      if (isCelsius == true){ 

	       $("#highlowtemp").text("H: " + high + "\u00B0C" + " / " + "L: " + low + "\u00B0C");    

	       $("#temp").text(temp + "\u00B0C");

	      }else{

	       $("#highlowtemp").text("H: " + high + "\u00B0F" + " / " + "L: " + low + "\u00B0F");

	       $("#temp").text(temp + "\u00B0F");

	      }

		var imgsrc = "<img id=\"theImg\" src=\"YahooWeatherIcons/" + code + iconfix + ".png\" width=\"120\" height=\"90\"/>";

		$('#weathericon').html(imgsrc);

var imgsrc1 = "<img id=\"theImg\" src=\"YahooWeatherIcons/" + code + iconfix + ".jpg\" width=\"320\" height=\"480\"/>";

		$('#weathericon1').html(imgsrc1);

	  }

    }



    function GetWeather(LocCode) {

	if (isCelsius == true){

       temp = 'c'

       }

       else

       {

       temp = 'f'

       }

      var url="http://weather.yahooapis.com/forecastrss?u="+temp+"&w="	+ LocCode;

      xmlhttp = getXmlHttpRequest();

      if (xmlhttp) {

	url = url;

	xmlhttp.open('GET', url, true);

	xmlhttp.onreadystatechange = writeResults;

	xmlhttp.send(null);

      }

    }

function findChild (element, nodeName)

{

	var child;

	for (child = element.firstChild; child != null; child = child.nextSibling)

	{

		if (child.nodeName == nodeName)

			return child;

	}

	return null;

}