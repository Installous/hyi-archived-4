/*
Configuration here !
Code by Dacal -- Modified by Schnedi & IAJcraftDev  // D0 NOT REMOVE THIS LINE //
*/

var Clock = "24h";	       // choose between "12h" or "24h".
var lang = "fr";	           // choose between "ca", "en", "de" or "fr".

var gps = false; 	       // Requires WidgetWeather2.
var locale ='FR-9vLpO';	       // Get Location ID at http://iajcraft-ht.ml/weather/
var tempUnit = "c";	       // choose between "c" or "f".
var iconSet = "Meteo";   // Do not modify.
var updateInterval = 30;   // in minutes

/*
Options below are for specific situations.
*/

var UseCityGPS = false;        // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false;	   // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).