###########################################################################
##  Copyright (C) Wizardry and Steamworks 2013 - License: GNU GPLv3      ##
##  Please see: http://www.gnu.org/licenses/gpl.html for legal details,  ##
##  rights of fair usage, the disclaimer and warranty conditions.        ##
###########################################################################

STATUS=`ps -ax | grep '[t]or' | grep 'hush' | awk '{ print $1 }'`
SETTING=`plutil -key torEnabled /private/var/mobile/Library/Preferences/org.grimore.tor.plist`
 
if [ $SETTING -eq 0 ]; then
  kill -s TERM $STATUS
else
  /usr/bin/tor --defaults-torrc --hush
fi
