var meta = {
    changing: false,
	setBattery: function(battery, timeout, count, element, elwidth) {
        var calc, width, interval;
        width = 0;
        calc = Math.round((battery / 100) * elwidth);
        document.querySelector('.' + element).style.width = calc + 'px';
    },
    loadBattery: function() {
        document.getElementById('percent').innerHTML = cyMeta.getBattery() + "%";
        this.setBattery(cyMeta.getBattery(), 1, 3, 'batterybar', '270');
    },
};

function tick() {
    meta.loadBattery();
    setTimeout(tick, 10000);
}
tick();