var SResolution = "128"; // Configure style: 32, 64, 128 or 256. Default is 128
var SplatRadius = "0.5"; // Configure the splat radius between 0.1 and 0.9. Default is 0.5
var EnableBloom = true; // Enables the bloom effect to the smoke!
