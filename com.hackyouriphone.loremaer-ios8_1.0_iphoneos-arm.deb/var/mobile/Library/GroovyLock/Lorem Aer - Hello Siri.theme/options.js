// Please edit your name below.
var name = "Siri";

// Dato finner man under, trengs ikke endres. Med mindre man vil endre navn på dager og måneder. 
var date   = new Date();

// Gjeldende dato med oversettelse til engelsk
var day = date.getDay();
var season = '';
if(day == "0"){ day = "Sunday"; }
    else if(day == "1"){ day = "Monday"; }
    else if(day == "2"){ day = "Tuesday"; }
    else if(day == "3"){ day = "Wednesday"; }
    else if(day == "4"){ day = "Thursday"; }
    else if(day == "5"){ day = "Friday"; }
    else if(day == "6"){ day = "Saturday"; }

var ditm = date.getDate();
if(ditm == '1'){ ditm = ditm + 'st'; }
    else if(ditm == '2'){ ditm = ditm + 'nd'; }
    else if(ditm == '3'){ ditm = ditm + 'rd'; }
    else if(ditm == '21'){ ditm = ditm + 'st'; }
    else if(ditm == '22'){ ditm = ditm + 'nd'; }
    else if(ditm == '23'){ ditm = ditm + 'rd'; }
    else if(ditm == '31'){ ditm = ditm + 'st'; }
    else { ditm = ditm + 'th'; }

var month = date.getMonth();
if(month == "0"){ month = "January"; season = "snowy day in"; }
    else if(month == "1"){ month = "February"; season = "cold day in "; }
    else if(month == "2"){ month = "March"; season = "cloudy day in "; }
    else if(month == "3"){ month = "April"; season = "windy day in "; }
    else if(month == "4"){ month = "May"; season = "floral day in "; }
    else if(month == "5"){ month = "June"; season = "sunny day in "; }
    else if(month == "6"){ month = "July"; season = "hot day in "; }
    else if(month == "7"){ month = "August"; season = "warm day in "; }
    else if(month == "8"){ month = "September"; season = "rainy day in "; }
    else if(month == "9"){ month = "October"; season = "foggy day in "; }
    else if(month == "10"){ month = "November"; season = "cold day in "; }
    else if(month == "11"){ month = "December"; season = "freezing day in "; }
    

// Time på dagen
var hour   = date.getHours();

var minute = date.getMinutes();


if(minute <= '9')
{
    minute = '0' + minute;
}

if(hour < '9')
{
    hour = '0' + hour;
}

var nod = "";
if(hour < '12'){ nod = "Good morning"; }
    else if(hour > '12' && hour < '18' ){ nod = "Good afternoon"; }
    else if(hour > '18' && hour < '23' ){ nod = "Good evening"; }
    else { nod = "Hello"; }


// Resultat,  her settes html inn
document.getElementById("welcome").innerHTML = nod;
document.getElementById("name").innerHTML = name;
document.getElementById("info").innerHTML = 'currently the time is';
document.getElementById("time").innerHTML = hour + ':' + minute;
document.getElementById("info2").innerHTML = 'a ' + season + month;
