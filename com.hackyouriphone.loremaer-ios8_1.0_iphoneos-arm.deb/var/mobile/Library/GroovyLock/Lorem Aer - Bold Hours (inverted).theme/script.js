var date   = new Date();

// Gjeldende dato med oversettelse til engelsk
var day = date.getDay();
if(day == "0"){ day = "Sunday"; }
    else if(day == "1"){ day = "Monday"; }
    else if(day == "2"){ day = "Tuesday"; }
    else if(day == "3"){ day = "Wednesday"; }
    else if(day == "4"){ day = "Thursday"; }
    else if(day == "5"){ day = "Friday"; }
    else if(day == "6"){ day = "Saturday"; }

var ditm = date.getDate();
if(ditm == '1'){ ditm = ditm + 'st'; }
    else if(ditm == '2'){ ditm = ditm + 'nd'; }
    else if(ditm == '3'){ ditm = ditm + 'rd'; }
    else if(ditm == '21'){ ditm = ditm + 'st'; }
    else if(ditm == '22'){ ditm = ditm + 'nd'; }
    else if(ditm == '23'){ ditm = ditm + 'rd'; }
    else if(ditm == '31'){ ditm = ditm + 'st'; }
    else { ditm = ditm + 'th'; }

var month = date.getMonth();
if(month == "0"){ month = "January"; }
    else if(month == "1"){ month = "February"; }
    else if(month == "2"){ month = "March"; }
    else if(month == "3"){ month = "April"; }
    else if(month == "4"){ month = "May"; }
    else if(month == "5"){ month = "June"; }
    else if(month == "6"){ month = "July"; }
    else if(month == "7"){ month = "August"; }
    else if(month == "8"){ month = "September"; }
    else if(month == "9"){ month = "October"; }
    else if(month == "10"){ month = "November"; }
    else if(month == "11"){ month = "December"; }
    

// Time på dagen
var hour   = date.getHours();
var minute = date.getMinutes();


if(minute < "9")
{
    minute = '0' + minute;
}

if(hour < "9")
{
    hour = '0' + hour;
}


// Resultat,  her settes html inn

document.getElementById("time").innerHTML = '<span style="font-family: ArimoBold;">' + hour + '</span>' + minute;
document.getElementById("day").innerHTML = day + ', ' + ditm + ' of ' + month;

