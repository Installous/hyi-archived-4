/*
 *  BeeKeyboard ( kr.iolate.beekeyboard )
 *  Version: 1.7
 *
 *  iolate ( iolate@me.com )
 *  Twitter: @iolate_e
 *
 */

#import "BeeKeycode.h"

#ifndef _BEEKEYBOARD_H_
#define _BEEKEYBOARD_H_

typedef struct {
    int usagePage;
    int modifier;
    int keyCode;
    BOOL isPress;
    BOOL global;
    BOOL onEditMode;
} BKKeyEvent;

#endif

#define BK NSClassFromString(@"BeeKeyboard")

@interface BeeKeyboard
/*
 addonName: your addon name. if your bundle name is Basic.bundle, "Basic" is your addon name.
 table: defaults entry in Setting info file without "BeeKeyboard/".
 ex, defaults - "BeeKeyboard/Basic" ====> Table:@"Basic"
 
 return value: key entry in global.plist or local.plist
 */
+(NSString *)eventNameFromKeyEvent:(BKKeyEvent *)event withAddonName:(NSString *)addonName andTable:(NSString *)table;


/*
 global: if global mode => YES, if local(default, app) mode => NO
 keyString: @"usagePage.modStat.keyCode"
 
 return value: key entry in global.plist or local.plist
 */
+(NSString *)eventNameFromKeyString:(NSString *)keyString withAddonName:(NSString *)addonName andTable:(NSString *)table isGlobal:(BOOL)global;


/*
 eventName: key entry in Setting info file.
 return value: @"usagePage.modStat.keyCode"
 */
+(NSString *)keyStringFromEventName:(NSString *)eventName withAddonName:(NSString *)addonName isGlobal:(BOOL)global;

//=========================================================================

/*
 You cannot use MSHookIvar on BeeKeyboard addon.
 So, instead of MSHookIvar, Use BKHookIvar!
 
 Example:
 NSObject* object = BKHookIver(NSObject*, self, "_object");
 */
#define BKHookIvar(type, self, name) *(type *)[BK _BKHookIvarName:name inObject:self]
+(void *)_BKHookIvarName:(const char*)name inObject:(id)self_;

@end

/*
 #define BKHookIvar(type, self, name) *(type *)_BKHookIvar(self, name)
 void* _BKHookIvar(id self_, const char* name) {
 Ivar ivar = class_getInstanceVariable(object_getClass(self_), name);
 #if __has_feature(objc_arc)
 void *pointer = (ivar == NULL) ? NULL : (char *)((__bridge void *)self_) + ivar_getOffset(ivar);
 #else
 void *pointer = (ivar == NULL) ? NULL : (char *)(self_) + ivar_getOffset(ivar);
 #endif
 return pointer;
 }
 */



