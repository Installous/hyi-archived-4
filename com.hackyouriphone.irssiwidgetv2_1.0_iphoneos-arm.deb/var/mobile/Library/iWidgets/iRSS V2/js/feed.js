(function ($) {
    $.fn.Feed = function (opt) {
        var def = $.extend({
            FeedUrl: "",
            MaxCount: 10,
            ShowDesc: true,
            ShowPubDate: true,
            ShowTitle: true,
            TitleCharacterLimit: 70,
            DescCharacterLimit: 160,
            TitleLinkTarget: "_blank",
            DateFormat: "",
            DateFormatLang:"en"
        }, opt);

        var id = $(this).attr("id"), i, s = "",dt;
        $("#" + id).empty().append('<img src="" />');


        $.ajax({
            url: "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=" + def.MaxCount + "&output=json&q=" + encodeURIComponent(def.FeedUrl) + "&hl=en&callback=?",
            dataType: "json",
            success: function (data) {
                $("#" + id).empty();
                $.each(data.responseData.feed.entries, function (e, item) {
                    if(def.ShowTitle){
                        if (def.TitleCharacterLimit > 0 && item.title.length > def.TitleCharacterLimit){
                            s += '<li><div class="itemTitle"><a href="'+item.link+'" target="_blank" >' + item.title.substr(0, def.TitleCharacterLimit) + "</a>...</div>";
                       
                         }
                         else{
                            s += '<li><div class="itemTitle"><a href="'+item.link+'" target="_blank" >' + item.title + "</a></div>";
                        
                         }
                    }
                    else{
                         s += '<li><div class="itemTitle"><a href="" target="_blank" >'+ "</a></div>";
                   
                    }
                    if (def.ShowPubDate){
                        dt= new Date(item.publishedDate);
                        if(dt == "Invalid Date"){
                            var d = new Date();
                            dt=d;
                        }
                        if ($.trim(def.DateFormat).length > 0) {
                            try {
                                moment.lang(def.DateFormatLang);
                                s += '<div class="itemDate">' + moment(dt).format(def.DateFormat) + "</div>";
                            }
                            catch (e){s += '<div class="itemDate">' + dt.toLocaleDateString() + "</div>";}                            
                        }
                        else {
                            s += '<div class="itemDate">' + dt.toLocaleDateString() + "</div>";
                        }                        
                    }
                    if (def.ShowDesc) {
                        if (def.DescCharacterLimit > 0 && item.content.length > def.DescCharacterLimit) {
                            s += '<div class="itemContent">' + item.content.substr(0, def.DescCharacterLimit) + "...</div>";
                        }
                        else {
                            s += '<div class="itemContent">' + item.content + "</div>";
                        }
                    }
                });
                $("#" + id).append('<ul class="feedlist">' + s + "</ul>");
                $('.itemContent > br').remove(); //remove br
                $('.itemContent > .itemDate').remove();
                $(".itemContent a").remove(); //remove images
                $('.itemContent p').contents().unwrap(); //remove paragraph tag
                $('.itemTitle a').css('color',tcolor);
                $('.itemTitle a').css('font-size',tsize);
                $('.itemDate').css('color',dcolor);
                $('.feedlist li').css('background-color',bgcolor);
                $('.feedlist li').css('border-radius',bradius+"px");
                $('.itemDate').css('font-size',dsize);
                $('.feedlist').css('color',fcolor);
                $('.feedlist').css('font-size',fsize+"px");
                $('.feedlist').css('text-align',talign);
                $('.feedlist li').css('-webkit-box-shadow',bshadow);
            }
        });
    };
})(jQuery);

