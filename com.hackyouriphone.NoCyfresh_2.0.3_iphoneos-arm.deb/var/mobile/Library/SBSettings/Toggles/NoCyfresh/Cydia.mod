#!/bin/bash
C=/${0}
C=${C%/*}
declare -a flags
[[ :${DYLD_INSERT_LIBRARIES}: == */MobileSubstrate.dylib: ]] && flags[${#flags[@]}]=--substrate
if [ -f /var/mobile/Library/SBSettings/Toggles/NoCyfresh/CydiaRefreshBlocked ]
then
	echo "Disabling Cydia Refresh"
	/var/mobile/Library/SBSettings/Toggles/NoCyfresh/nocyfreshhelper -d /private/var/lib/cydia/metadata.plist
else
	echo "Enabling Cydia Refresh"
	/var/mobile/Library/SBSettings/Toggles/NoCyfresh/nocyfreshhelper -e /private/var/lib/cydia/metadata.plist
fi;
exec "${C:-.}"/Cydia_ "${flags[@]}" -- "$@" 2>>/tmp/cydia.log
