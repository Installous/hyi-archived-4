/*

Configuration here !

Done by Dacal - Modded by iPako

For weather code, go to http://weather.yahoo.com/ and search for your city. The correct zip code is in the URL (only numbers)

*/





var Clock = "12h";		  // choose between "12h" or "24h"

var lang = "en";	       // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english





var gps = true; 	       // Requires MyLocation app

var locale = 2379574;		// Yahoo Weather (used if gps set to false or myLocation.txt file not found)

var tempUnit = "f";	       // f for fahrenheit

var updateInterval = 60;       // in minutes

/*

Interactive LockScreen Widget are incompatible with LockInfo !

In some case, forecast don't display even without LockInfo.

You can try to put the variable below to true, not perfect

(slower response on animation), but better than nothing !

*/



var ChangeClick = false; // True ONLY if you have problem to show forecast when touch the screen





