var MainColor = "Black";
var SecondColor = "linear-gradient(to top, #7474bf, #348ac7)";
var ZoomLevel = 100;