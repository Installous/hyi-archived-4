window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentDate1 = currentTime.getDate() - 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("fecha").innerHTML = currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];

document.getElementById('weekday').style.color = Weekday_color;

document.getElementById('hour').style.color = Clock_color;
document.getElementById('texthm').style.color = Clock_color;
document.getElementById('minute').style.color = Clock_color;
document.getElementById('ampm').style.color = Clock_color;

document.getElementById('month').style.color = Calendar_color;
document.getElementById('fecha').style.color = Calendar_color;

document.getElementById('temp').style.color = Temperature_color;
document.getElementById('texto').style.color = Temperature_color;

document.getElementById('LevelDisplay').style.color = Battery_color;
document.getElementById('textob').style.color = Battery_color;

document.getElementById('textca1').style.color = Separator_color;
document.getElementById('textca2').style.color = Separator_color;

c1.style.backgroundColor = SquareOne_color;

c2.style.backgroundColor = SquareTwo_color;

}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}