 var Celsius = false; // Celsius
 var Locale = "38671"; //Set your location here. Uses weather.com code not yahoo.
 var TwentyFourHourClock = false;  //24 Hour Clock
 var HideBackground = true; //hide background to show settings wallpaper.
 var HideClock = true; //hide dusk clock
 var HideDate = true; //hide dusk date
 var Curlanguage = "en"; //options "de","fr","sp","it"
 var WeatherRefresh = 10; //in minutes