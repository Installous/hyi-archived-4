var FooterTextColor = "White";
var ZoomLevel = 100;
var DarkIcon = false;
