/* ------Single or DoubleTap By Ian Nicoll ------ */

var doubleTapped = false;

var forecastdisplay = true;
var iOS = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false;
if (iOS == true) { var touchmode = "touchend"; } else { var touchmode = "click"; }


function StartTouch() {
	document.getElementById("forecastContainer").className = "fade-out";
	forecastdisplay = false;
	document.getElementById("touchForecast").addEventListener(touchmode, touch, false);

}

function touch(event) {
	if (useDoubleTap == true) {
		if(!doubleTapped) {
			doubleTapped = true;
			setTimeout( function() { doubleTapped = false; }, 500 );
			return false;
		}
	}
    event.preventDefault();

	if (forecastdisplay == false) {

		document.getElementById("forecastContainer").className = "fade-in";
		document.getElementById("CurrentConditionIconContainer").className = "scaleZero";
		document.getElementById("leftInfoContainer").className = "moveLeft";
		document.getElementById("rightInfoContainer").className = "moveRight";

		forecastdisplay = true;

	} else {

		document.getElementById("forecastContainer").className = "fade-out";	
		document.getElementById("CurrentConditionIconContainer").className = "scaleNormal";
		document.getElementById("leftInfoContainer").className = "moveNormal";
		document.getElementById("rightInfoContainer").className = "moveNormal"; 

		forecastdisplay = false;

	}

}

