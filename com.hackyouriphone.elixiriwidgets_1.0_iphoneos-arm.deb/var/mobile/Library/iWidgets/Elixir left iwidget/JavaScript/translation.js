// From UniAW7.1 by Ian Nicoll & Dacal

// TRANSLATION FOR MAIN ELEMENTS.

switch (lang) {
case "no": 
		var days = ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"];
		var months = ["Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"];
		var hightext = "Høy ";
		var lowtext = "Lav ";
		var sunrisetext ="Soloppgang";
		var sunsettext = "Solnedgang";
		var moonrisetext ="Måneoppgang";
		var moonsettext = "Månenedgang";		
		var feelsliketext = "Føles som ";
		var pressuretext = "Lufttrykk ";
		var lastupdatetext = "Oppdatert ";
		var xmlupdatetext = "Oppdatert kl ";
		var visibilitytext = "Sikt";
		var humiditytext = "Luftfuktighet ";
		var windtext = "Vind ";
		var UVIndextext = "UV ";
		var Dewpointtext = "Duggpunkt ";
	var forecasttext = "Varsel";
		var nowindtext = "Vindstille";
		var WeatherDesc = [
			"Tornado",
			"Tropisk storm",
			"Orkan",
			"Kraftige tordenbyger",
			"Tordenbyger",
			"Blandet Regn og snø",
			"Blandet regn og sludd",
			"Blandet snø og sludd",
			"Underkjølt duskregn",
			"Duskregn",
			"Underkjølt regn",
			"Regnbyger",
			"Regn",
			"Snøbyger",
			"Lette snøbyger",
			"Snøfokk",
			"Snø",
			"Hagl",
			"Sludd",
			"Støv",
			"Tåke",
			"Dis",
			"Røykfylt",
			"Mye Vind",
			"Vindkuler",
			"Frost",
			"Skyet ",
			"Muligheter for regn",
			"Muligheter for regn",
			"Delvis skyet",
			"Delvis skyet",
			"Klart",
			"Solskinn",
			"Det meste klart",
			"For det meste sol",
			"Blandet regn og hagl",
			"Varmt",
			"Isolerte tordenbyger",
			"Spredte tordenbyger",
			"Spredte tordenbyger",
			"Spredte regnbyger",
			"Kraftig snøfall",
			"Spredte snøbyger",
			"Kraftig snøfall",
			"Delvis skyet",
			"Regn og torden",
			"Snøbyger",
			"Isolerte regn og torden",
			"ikke mottak"];
	break;
	case "fr":
		var days = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
		var months = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Decembre"];
		var hightext = "Max ";
		var lowtext = "Min ";
		var sunrisetext = "Lever";
		var sunsettext = "Coucher";
		var moonrisetext ="Lev.&nbsp;(lune)";
		var moonsettext = "Couc.&nbsp;(lune)";
		var feelsliketext = "Ressentie ";
		var lastupdatetext = "Vérifié à ";
		var xmlupdatetext = "Mis à jour à ";
		var humiditytext = "Humidité "; 
		var visibilitytext = "Visibilité";	
		var pressuretext = "Pression ";
		var windtext = "Vent ";
		var UVIndextext = "Indice UV ";
		var Dewpointtext = "Point de rosée ";
	var forecasttext = "Prévision de";
		var nowindtext = "Pas de vent";
		var WeatherDesc = [
			"Tornade",
			"Orage tropical",
			"Ouragan",
			"Orages violents",
			"Orages",
			"Pluie et neige mélées",
			"Pluie et grêle mélées",
			"Neige et grêle mélées",
			"Bruine verglaçante",
			"Bruine",
			"Pluie verglaçante",
			"Averses",
			"Pluie",
			"Quelques flocons",
			"Faibles chutes de neige",
			"Rafales de neige",
			"Neige",
			"Grêle",
			"Neige fondue",
			"Poussiéreux",
			"Brouillard",
			"Brume",
			"Brumeux",
			"Tempête",
			"Vent",
			"Temps froid",
			"Temps nuageux ",
			"Très nuageux",
			"Très nuageux",
			"Partiellement nuageux",
			"Partiellement nuageux",
			"Ciel dégagé",
			"Ensoleillé",
			"Beau temps",
			"Beau temps",
			"Pluie et grêles mélées",
			"Temps chaud",
			"Orages isolés",
			"Orages éparses",
			"Orages éparses",
			"Averses éparses",
			"Fortes chutes de neige",
			"Chutes de neige éparses",
			"Fortes chutes de neige",
			"Partiellement nuageux",
			"Orages",
			"Chute de neige",
			"Orages isolés",
			"Non disponible"];
    break;
	case "ge":
		var days = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
		var months = ["Januar", "Februar", "Maerz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];
		var hightext = "Hoch ";
		var lowtext = "Tief ";
		var sunrisetext = "Morgen";
		var sunsettext = "Abend";
		var moonrisetext ="MondAufgang";
		var moonsettext = "Mond";
		var feelsliketext = "Gefühlte ";
		var lastupdatetext = "Geprüft ";
		var xmlupdatetext = "Aktualisiert ";
		var visibilitytext = "Sichtweite";
		var humiditytext = "Luftfeuchte ";
		var pressuretext = "Luftdruck ";
		var windtext = "Wind ";
		var UVIndextext = "UV-index ";
		var Dewpointtext = "Taupunkt ";
	var forecasttext = "Prognose";
		var nowindtext = "Kein wind";
		var WeatherDesc = [
			"Tornado",
			"Tropischer sturm",
			"Wirbelsturm",
			"Schwere gewitter",
			"Gewitter",
			"Regen und schnee",
			"Graupelschauer",
			"Schneeregen",
			"Gefrierender nieselregen",
			"Nieselregen",
			"Gefrierender regen",
			"Schauer",
			"Regen",
			"Schneegest&ouml;ber",
			"Leichte schneeschauer",
			"Schneetreiben",
			"Schnee",
			"Hagel",
			"Schneeregen",
			"Staubig",
			"Nebelig",
			"Dunstschleier",
			"Dunstig",
			"St&uuml;rmisch",
			"Windig",
			"Kalt",
			"Bew&ouml;lkt ",
			"Meist bew&ouml;lkt",
			"Meist bew&ouml;lkt",
			"Teilweise bew&ouml;lkt",
			"Teilweise bew&ouml;lkt",
			"Klar",
			"Sonnig",
			"Heiter",
			"Meist sonnig",
			"Regen und hagel",
			"Heiss",
			"&Ouml;rtliche gewitter",
			"Vereinzelte gewitte",
			"Vereinzelte gewitte",
			"Vereinzelte schauer",
			"Starker schneefall",
			"Vereinzelte schneeschauer",
			"Starker schneefall",
			"Teilweise bew&ouml;lkt",
			"Gewitter",
			"Scheeschauer",
			"Ouml;rtliche gewitterschauer",
			"Nicht verfuegbar"];
	break;
	case "nl":
		var days = ["Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag"];
		var months = ["Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December"];
		var hightext = "Hoog ";
		var lowtext = "Laag ";
		var sunrisetext ="Ochtend";
		var sunsettext = "Nacht";
		var moonrisetext ="Moonrise";
		var moonsettext = "Moonset";
		var feelsliketext = "Feels like ";
		var lastupdatetext = "Gecontroleerd ";
		var xmlupdatetext = "Bijgewerkt ";
		var humiditytext = "Vochtigheid ";
		var visibilitytext = "Zichtbaarheid";	
		var pressuretext = "Druk ";
		var windtext = "Wind ";
		var UVIndextext = "UV-index ";
		var Dewpointtext = "Dauwpunt ";
	var forecasttext = "Forecast";
		var nowindtext = "Geen wind";
		var WeatherDesc = [
			"Tornado",
			"Tropische storm",
			"Wervelwind",
			"Zware onweersbuien",
			"Onweersbuien",
			"Regen en sneeuw",
			"Regen en ijzel",
			"Sneeuw en ijzel",
			"Bevriezende motregen",
			"Motregen",
			"Ijzel",
			"Buien",
			"Regen",
			"Sneeuwvlagen",
			"Lichte sneeuwbuien",
			"Sneeuw drift",
			"Sneeuw",
			"Hagel",
			"Ijzel",
			"Stoffig",
			"Mistig",
			"Wazig",
			"Wazig",
			"Stormachtig",
			"Winderig",
			"Koud",
			"Bewolkt ",
			"Algemeen bewolkt",
			"Algemeen bewolkt",
			"Gedeeltelijk bewolkt",
			"Gedeeltelijk bewolkt",
			"Helder",
			"Zonnig",
			"Veelal helder",
			"Overwegend zonnig",
			"Regen en hagel",
			"Heet",
			"Geisoleerde onweersbuien",
			"Verspreide onweersbuien",
			"Verspreide onweersbuien",
			"Verspreide buien",
			"Zware sneeuw",
			"Verspreide sneeuwbuien",
			"Zware sneeuw",
			"Gedeeltelijk bewolkt",
			"Onweersbuien",
			"Sneeuwbuien",
			"Geisoleerde onweersbuien",
			"Niet beschikbaar"];
	break;
	case "fi":
		var days = ["Sunnuntai", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai"];
		var months = ["Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kesäkuu", "Heinäkuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu"];
		var hightext = "Korkein ";
		var lowtext = "Alin ";
		var sunrisetext = "Aamu";
		var sunsettext = "Yö";
		var moonrisetext ="kuun nousu";
		var moonsettext = "Moon asetettu";
		var feelsliketext = "Tuntuu ";
		var pressuretext = "Paine ";	
		var lastupdatetext = "tarkastetaan ";
		var xmlupdatetext = "päivitetty ";
		var visibilitytext = "Näkyvyys";
		var humiditytext = "Ilmankosteus ";
		var windtext = "Tuuli ";
		var UVIndextext = "UV-indeksi ";
		var Dewpointtext = "Kastepiste ";
	var forecasttext = "Ennuste";
		var nowindtext = "Ei tuulta";
		var WeatherDesc = [
			"Tornaado",
			"Trooppinen myrsky",
			"Wervelwind",
			"Rankkoja ukkoskuuroja",
			"Ukkosmyrskyj&auml;",
			"Vesisadetta ja r&auml;nt&auml;&auml;",
			"Vesi ja r&auml;nt&auml;sadetta",
			"Lumi ja r&auml;nt&auml;sadetta",
			"J&auml;&auml;t&auml;v&auml;&auml; tihkusadetta",
			"Tihkusadetta",
			"J&auml;&auml;t&auml;v&auml;&auml; sadetta",
			"Sadekuuroja",
			"Sade",
			"Lumisadetta",
			"Heikkoja lumikuuroja",
			"Lumituisku",
			"Lumisadetta",
			"Rakeita",
			"R&auml;nt&auml;&auml;",
			"P&ouml;lyist&auml;",
			"Sumuista",
			"Utuista",
			"Utuista",
			"Ei tietoja",
			"Tuulista",
			"kylm&auml;&auml;",
			"Pilvist&auml;",
			"Enimm&auml;kseen pilvist&auml;",
			"Enimm&auml;kseen pilvist&auml;",
			"Puolipilvist&auml;",
			"Puolipilvist&auml;",
			"Selke&auml;&auml;",
			"Aurinkoista",
			"Selke&auml;&auml;",
			"Selke&auml;&auml;",
			"Vesisadetta ja raekuuroja",
			"Hellett&auml;",
			"Paikallisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia ukkoskuuroja",
			"Hajanaisia sadekuuroja",
			"Rankkaa lumisadetta",
			"Hajanaisia lumikuuroja",
			"Rankkaa lumisadetta",
			"Puolipilvist&auml;",
			"Ukkoskuuroja",
			"Lumikuuroja",
			"Paikallisia ukkoskuuroja",
			"Ei tietoja"];
    break; 
	case "sp":
		var days = ["Dom", "Lun", "Mar", "Mie", "Jue", "Vie", "Sab"];
		var months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
		var hightext = "Alto ";
		var lowtext = "Bajo ";
		var sunrisetext ="Mañana";
		var sunsettext = "Noche";
		var moonrisetext ="Luna";
		var moonsettext = "Luna set";
		var feelsliketext = "más como ";
		var lastupdatetext = "Comprobado ";
		var xmlupdatetext = "Actualizado ";
		var humiditytext = "Humedad ";
		var visibilitytext = "Visibilidad";
		var pressuretext = "Presion ";
		var windtext = "Viento ";
		var UVIndextext = "índice ";
		var Dewpointtext = "Punto de rocío ";
	var forecasttext = "Pronóstico";
		var nowindtext = "No hay viento";
		var WeatherDesc = [
			"Tornado",
			"Tormenta Tropical",
			"Huracan",
			"Tormentas electricas Severas",
			"Tormentas electricas",
			"Mezcla de lluvia y nieve",
			"Mezcla de lluvia y aguanieve",
			"Mezcla de nieve y aguaniev",
			"Llovizna helada",
			"Llovizna",
			"Lluvia bajo cero",
			"Chubascos",
			"Lluvia",
			"Rafagas de nieve",
			"Ligeras precipitaciones de nieve",
			"Viento y nieve",
			"Nieve",
			"Granizo",
			"Aguanieve",
			"Polvareda",
			"Neblina",
			"Bruma",
			"Humeado",
			"Tempestuoso",
			"Vientoso",
			"Frio",
			"Nublado ",
			"Mayormente nublado",
			"Mayormente nublado",
			"Parcialmente despejado",
			"Parcialmente despejado",
			"Despejado",
			"Soleado",
			"Mayormente despejado",
			"Mayormente soleado",
			"Mezcla de lluvia y granizo",
			"Caluroso",
			"Tormentas electricas aisladas",
			"Tormentas electricas dispersas",
			"Tormentas electricas dispersas",
			"Chubascos dispersos",
			"Nieve fuerte",
			"Precipitaciones de nieve dispersas",
			"Nieve fuerte",
			"Parcialmente despejado",
			"Lluvia con truenos y relampagos",
			"Precipitaciones de nieve",
			"Tormentas aisladas",
			"No disponible"];
    break;
	case "it":
		var days = ["Domenica", "Lunedi", "Martedì", "Mercoledì", "Giovedi", "Venerdì", "Sabato"];
		var months = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
		var hightext = "Alto ";
		var lowtext = "Basso ";
		var sunrisetext ="Alba";
		var sunsettext = "Tramonto";
		var moonrisetext ="La luna";
		var moonsettext = "Luna set";
		var feelsliketext = "Percepita ";
		var lastupdatetext = "Verificato ";
		var xmlupdatetext = "Aggiornato ";
		var humiditytext = "Umidita ";
		var visibilitytext = "Visibilita";
		var pressuretext = "Pressione ";
		var windtext = "Vento ";
		var UVIndextext = "Indice UV ";
		var Dewpointtext = "Punto di rugiada ";
	var forecasttext = "Previsione";
		var nowindtext = "No hay viento";
		var WeatherDesc = [
			"Tornado",
			"Tempesta tropicale",
			"Uragano",
			"Tuoni e fulmini",
			"Fulmini",
			"Misto pioggia e neve",
			"Misto pioggia e nevischio",
			"Misto neve e nevischio",
			"Grandine",
			"Pioggerella",
			"Grandine",
			"Diluvio",
			"Pioggia",
			"Raffiche di neve",
			"Poca neve",
			"Vento e neve",
			"Neve",
			"Grandine",
			"Nevischio",
			"Polvere",
			"Nebbiolina",
			"Nebbia",
			"Humeado",
			"Tempesa",
			"Ventoso",
			"Froddo",
			"Nuvoloso",
			"Molto nuvoloso",
			"Molto nuvoloso",
			"Parzialmente nuvoloso",
			"Parzialmente nuvoloso",
			"Sereno",
			"Soleggiato",
			"Parzialmente nuvoloso",
			"Prevalentemente soleggiato",
			"Misto neve e grandine",
			"Caldo",
			"Fulmini isolati",
			"Tempesta di fulmini",
			"Tempesta di fulmini",
			"Tempesta di pioggia",
			"Forti nevicate",
			"Neve sparsa",
			"Forti nevicate",
			"Parzialmente nuvoloso",
			"Rovesci temporaleschi",
			"Precipitazioni nevose",
			"Rovesci temporaleschi isolati",
			"Non disponibile"];
    break;
	case "ru":
		var days = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
		var months = ['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'];
		var hightext = "привет ";
		var lowtext = "вот ";
		var sunrisetext ="утро";
		var sunsettext = "закат";
		var moonrisetext ="Луна восход";
		var moonsettext = "Луна";
		var feelsliketext = "чувство ";
		var lastupdatetext = "проверено ";
		var xmlupdatetext = "обновленный ";
		var humiditytext = "Влажность ";
		var visibilitytext = "видимость";
		var pressuretext = "давление ";
		var windtext = "ветер ";
		var UVIndextext = "УФ-индекс ";
		var Dewpointtext = "Точка росы ";
	var forecasttext = "Прогноз";
		var nowindtext = "Нет ветра";
		var WeatherDesc = [
			"Торнадо",
			"Горячая буря",
			"Ураган",
			"Гроза",
			"Бури",
			"Дождь со снегом",
			"Дождь и мокрый снег",
			"Снег и мокрый снег",
			"Изморозь",
			"Изморось",
			"Ледяной дождь",
			"Дождь",
			"Дождь",
			"Снег с порывами",
			"Небольшой снег с дождем",
			"Снежные заряды",
			"Снег",
			"Град",
			"Дождь со снегом",
			"Пыль",
			"Туман",
			"Туман",
			"Туман",
			"Бурный",
			"Ветер",
			"Холодный",
			"Облачно ",
			"Небольшая облачность",
			"Небольшая облачность",
			"Переменная облачность",
			"Переменная облачность",
			"Ясно",
			"Солнечно",
			"Переменная облачность",
			"Кратковременные дожди",
			"Дождь и град",
			"Горячий",
			"Изолированные грозы",
			"Рассеянные грозы",
			"Рассеянные грозы",
			"Рассеянный дождь",
			"Сильный снег",
			"Рассеянный снег с дождем",
			"Сильный снег",
			"Переменная облачность",
			"Изолированные грозы с дождем",
			"Дождь со снегом",
			"Изолированные грозы с дождем",
			"Недоступно"];
	break;
	case "cn":
		var days = ["星期日","星期一","星期二","星期三","星期四","星期五","星期六"];
		var months = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
		var hightext = "最高 ";
		var lowtext = "最低 ";
		var sunrisetext = "日出";
		var moonrisetext ="月亮升起";
		var moonsettext = "月球集";
		var sunsettext = "日落";
		var feelsliketext = "感覺像";
		var pressuretext = "最高";	
		var lastupdatetext = "檢查 ";
		var xmlupdatetext = "更新 ";
		var visibilitytext = "能见度";
		var humiditytext = "湿度 ";
		var windtext = "风向 ";
		var UVIndextext = "紫外線指數 ";
		var Dewpointtext = "露点 ";
	var forecasttext = "预测";
		var nowindtext = "无风";
		var WeatherDesc = [
			"风卷残云",
			"热带风暴",
			"狂风暴雨",
			"电闪雷鸣",
			"电闪雷鸣",
			"雨雪霏霏",
			"雨雪霏霏",
			"雨雪纷纷",
			"寒风冷雨",
			"蒙蒙细雨",
			"凄风冷雨",
			"疾风骤雨",
			"雨",
			"俄而雪骤",
			"流风回雪",
			"狂风暴雪",
			"大雪纷飞",
			"天降冰雹",
			"雨雪霏霏",
			"飞沙走石",
			"云迷雾锁",
			"十面霾伏",
			"烟雾弥漫",
			"风起云涌",
			"风和日丽",
			"天寒地冻",
			"乌云蔽日",
			"浮云蔽日",
			"浮云蔽日",
			"云淡风轻",
			"云淡风轻",
			"晴空万里",
			"阳光明媚",
			"大部晴朗",
			"晴时多云",
			"冰雹带雨",
			"骄阳似火",
			"霹雳列缺",
			"电闪雷鸣",
			"电闪雷鸣",
			"急风骤雨",
			"大雪纷飞",
			"骤雪初歇",
			"大雪纷飞",
			"云淡风轻",
			"雷阵雨",
			"雨雪霏霏",
			"霹雳列缺",
			"自行判断"];
	break;
	case "tr": 
		var days = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma​​", "Cumartesi"]; 
		var months = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül","Ekim", "Kasım", "Aralık"]; 
		var hightext = "Yüksek "; 
		var lowtext = "Düşük "; 
		var sunrisetext = "Gündoğumu"; 
		var sunsettext = "Gün Batımı"; 
		var moonrisetext = "Ayın doğuşu"; 
		var moonsettext = "Ayın Batışı"; 
		var feelsliketext = "Hissedilen "; 
		var pressuretext = "Basınç "; 
		var lastupdatetext = "Güncellendi "; 
		var xmlupdatetext = "Güncelleme vakti "; 
		var visibilitytext = "Görüş mesafesi"; 
		var humiditytext = "Nem "; 
		var windtext = "Rüzgar "; 
		var UVIndextext = "UV Endeksi ";
		var Dewpointtext = "İşbâ ";
		var forecasttext = "Hava durumu"; 
		var nowindtext = "Rüzgar yok"; 
		var WeatherDesc = [
			"Kasırga", 
			"Tropik fırtına", 
			"Fırtına", 
			"Şiddetli fırtına", 
			"Gök gürültülü fırtına",
			"Karışık yağmur ve kar", 
			"Karışık yağmur ve sulusepken", 
			"Karışık kar ve sulusepken", 
			"Çisenti Donma", 
			"Çiseleyen yağmur", 
			"Dondurucu çiseleyen yağmur",
			"Sağanak", 
			"Yağmur", 
			"Hafif kar",
			"Hafif kar sağnağı", 
			"Esen kar", 
			"Kar", 
			"Dolu", 
			"Sulu kar", 
			"Toz", 
			"Sisli",
			"Sis", 
			"Dumanlı", 
			"Yaygaracı", 
			"Rüzgarlı", 
			"Soğuk", 
			"Bulutlu", 
			"Çoğunlukla bulutlu", 
			"Çoğunlukla bulutlu", 
			"Parçalı bulutlu", 
			"Parçalı bulutlu", 
			"Açık", 
			"Güneşli", 
			"Çoğunlukla açık", 
			"Hafif bulutlu", 
			"Karışık yağmur ve dolu", 
			"Sıcak", 
			"İzole gökgürültülü sağanak", 
			"Dağınık gökgürültülü sağanak",
			"Dağınık gökgürültülü sağanak",
			"Dağınık sağanak", 
			"Şiddetli kar", 
			"Dağınık sağanak kar", 
			"Şiddetli kar", 
			"Parçalı bulutlu", 
			"Gökgürültülü yağmur", 
			"Sağanak kar", 
			"Izole gökgürültülü yağmur", 
			"Müsait değil"];
	break;
	case "gr":
		var days = ["Κυριακή", "Δευτέρα", "Τρίτη", "Τετάρτη", "Πέμπτη", "Παρασκευή", "Σάββατο"];
		var months = ["Ιανουάριος", "Φεβρουάριος", "Μάρτιος", "Απρίλιος", "Μάιος", "Ιούνιος", "Ιούλιος", "Αύγουστος", "Σεπτέμβριος", "Οκτώβριος", "Νοέμβριος", "Δεκέμβριος"];
		var hightext = "Υψηλή ";
		var lowtext = "Χαμηλή ";
		var sunrisetext = "Ανατολή";
		var sunsettext = "Δύση";
		var moonrisetext ="Ανατολή";
		var moonsettext = "Δύση";
		var feelsliketext = "Αίσθηση ";
		var lastupdatetext = "ελέγχεται ";
		var xmlupdatetext = "Ανανέωση ";
		var humiditytext = "Υγρασία "; 
		var visibilitytext = "Ορατότητα";      
		var pressuretext = "Πίεση ";
		var windtext = "Άνεμος ";
		var UVIndextext = "Επίπεδο UV ";
		var Dewpointtext = "σημείο δρόσου ";
		var forecasttext = "Πρόβλεψη";
		var nowindtext = "Χωρίς αέρα";
		var WeatherDesc = [
			"Ανεμοστρόβιλος",
			"Τροπική Καταιγίδα",
			"Τυφώνας",
			"Ισχυρές Καταιγίδες",
			"Καταιγίδες",
			"Βροχή και Χιόνι",
			"Βροχή και Χιονόνερο",
			"Χιόνι και Χιονόνερο",
			"Παγωμένο Ψιλόβροχο",
			"Ψιλόβροχο",
			"Παγωμένη Βροχή",
			"Καταιγίδες",
			"βροχή",
			"Διαστήματα Χιονιού",
			"Ελαφρές Χιονοπτώσεις",
			"Χιονοθύελλα",
			"Χιονόπτωση",
			"Χαλαζόπτωση",
			"Χιονόνερο",
			"Σκόνη",
			"Ομιχλώδης",
			"Καταχνιά",
			"Ομιχλώδης",
			"Θυελλώδης",
			"Ανεμώδης",
			"Κρύος",
			"Νεφελώδης ",
			"Κυρίως Νεφελώδης",
			"Κυρίως Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Μερικώς Νεφελώδης",
			"Αίθριος",
			"Ηλιόλουστος",
			"Κυρίως αίθριος",
			"Κυρίως λιακάδα",
			"Βροχή και Χαλάζι",
			"Ζεστός Καιρός",
			"Μεμονωμένες Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Ασθενείς Καταιγίδες",
			"Πιθανές Βροχές",
			"Ισχυρή Χιονόπτωση",
			"Πιθανή Χιονόπτωση",
			"Ισχυρή Χιονόπτωση",
			"Μερικώς Νεφελώδης",
			"Καταιγίδες",
			"Χιονόπτωση",
			"Μεμονωμένες Καταιγίδες",
			"Μη Διαθέσιμος"];
	break;	
	default: 
		var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		var hightext = "Hi ";
		var lowtext = "Lo ";
		var sunrisetext ="Sunrise";
		var sunsettext = "Sunset";
		var moonrisetext ="Moonrise";
		var moonsettext = "Moonset";
		var feelsliketext = "Feels like ";
		var lastupdatetext = "Checked at ";
		var xmlupdatetext = "Updated at ";
		var humiditytext = "Humidity ";
		var visibilitytext = "Visibility";
		var pressuretext = "Pressure ";
		var windtext = "Wind ";
		var UVIndextext = "UV index ";
		var Dewpointtext = "Dew point ";
		var forecasttext = "Forecast";
		var nowindtext = "No wind";
		var WeatherDesc = [
			"Tornado",
			"Tropical storm",
			"Hurricane",
			"Severe thunderstorms",
			"Thunderstorms",
			"Mixed rain and snow",
			"Mixed rain and sleet",
			"Mixed snow and sleet",
			"Freezing drizzle",
			"Drizzle",
			"Freezing rain",
			"Showers",
			"Rain",
			"Snow flurries",
			"Light snow showers",
			"Blowing snow",
			"Snow",
			"Hail",
			"Sleet",
			"Dust",
			"Foggy",
			"Haze",
			"Smoky",
			"Blustery",
			"Windy",
			"Cold",
			"Cloudy",
			"Mostly cloudy",
			"Mostly cloudy",
			"Partly cloudy",
			"Partly cloudy",
			"Clear",
			"Sunny",
			"Mostly clear",
			"Mostly sunny",
			"Mixed rain and hail",
			"Hot",
			"Isolated thunderstorms",
			"Scattered thunderstorms",
			"Scattered thunderstorms",
			"Scattered showers",
			"Heavy snow",
			"Scattered snow showers",
			"Heavy snow",
			"Partly cloudy",
			"Thundershowers",
			"Snow showers",
			"Isolated thundershowers",
			"Not available"];
	break;
}

function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
	}
}

function WindDescription() {
		switch (lang) {
		case "no":			
			if (obj.windspeed >= 118) { var winddesc = "orkan"; }
			if (obj.windspeed < 118) { var winddesc = "sterk storm"; }
			if (obj.windspeed < 103){ var winddesc = "full storm"; }
			if (obj.windspeed < 89){ var winddesc = "liten storm"; }				
			if (obj.windspeed < 75){ var winddesc = "sterk kuling"; }
			if (obj.windspeed < 62) { var winddesc = "stiv kuling"; }
			if (obj.windspeed < 50) { var winddesc = "liten kuling"; }
			if (obj.windspeed < 39) { var winddesc = "frisk bris"; }
			if (obj.windspeed < 29) { var winddesc = "moderat bris"; }	
			if (obj.windspeed < 20) { var winddesc = "laber bris"; }
			if (obj.windspeed < 12) { var winddesc = "lett bris"; }
			if (obj.windspeed < 6) { var winddesc = "svak vind"; }
			if (obj.windspeed < 1) { var winddesc = "flau vind"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "cn":			
			if (obj.windspeed >= 118) { var winddesc = "飓风级风力"; }
			if (obj.windspeed < 118) { var winddesc = "猛烈的风"; }
			if (obj.windspeed < 103){ var winddesc = "强风"; }
			if (obj.windspeed < 89){ var winddesc = "八级大风"; }				
			if (obj.windspeed < 75){ var winddesc = "大风"; }
			if (obj.windspeed < 62) { var winddesc = "高风"; }
			if (obj.windspeed < 50) { var winddesc = "强风"; }
			if (obj.windspeed < 39) { var winddesc = "清新的微风"; }
			if (obj.windspeed < 29) { var winddesc = "和风"; }	
			if (obj.windspeed < 20) { var winddesc = "微风"; }
			if (obj.windspeed < 12) { var winddesc = "微风"; }
			if (obj.windspeed < 6) { var winddesc = "光气"; }
			if (obj.windspeed < 1) { var winddesc = "小风"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "fr":
			if (obj.windspeed >= 118) { var winddesc = "ouragan"; }
			if (obj.windspeed < 118) { var winddesc = "vent violent"; }
			if (obj.windspeed < 103){ var winddesc = "vent soufflant en temp&ecirc;te"; }
			if (obj.windspeed < 89){ var winddesc = "fort coup de vent"; }				
			if (obj.windspeed < 75){ var winddesc = "coup de vent"; }
			if (obj.windspeed < 62) { var winddesc = "vent fort"; }
			if (obj.windspeed < 50) { var winddesc = "forte brise"; }
			if (obj.windspeed < 39) { var winddesc = "bonne brise"; }
			if (obj.windspeed < 29) { var winddesc = "brise mod&eacute;r&eacute;e"; }	
			if (obj.windspeed < 20) { var winddesc = "douce brise"; }
			if (obj.windspeed < 12) { var winddesc = "l&eacute;g&egrave;re brise"; }
			if (obj.windspeed < 6) { var winddesc = "un peu d'air"; }
			if (obj.windspeed < 1) { var winddesc = "faible vent"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "ru":
			if (obj.windspeed >= 118) { var winddesc = "ураган"; }
			if (obj.windspeed < 118) { var winddesc = "сильный ветер"; }
			if (obj.windspeed < 103){ var winddesc = "штурмовой ветер"; }
			if (obj.windspeed < 89){ var winddesc = "сильный порыв ветра"; }	  
			if (obj.windspeed < 75){ var winddesc = "шторм"; }
			if (obj.windspeed < 62) { var winddesc = "сильный ветер"; }
			if (obj.windspeed < 50) { var winddesc = "сильный ветер"; }
			if (obj.windspeed < 39) { var winddesc = "хороший ветер"; }
			if (obj.windspeed < 29) { var winddesc = "умеренный ветер"; }	
			if (obj.windspeed < 20) { var winddesc = "слабый ветер"; }
			if (obj.windspeed < 12) { var winddesc = "спокойный ветер"; }
			if (obj.windspeed < 6) { var winddesc = "легкий ветер"; }
			if (obj.windspeed < 1) { var winddesc = "слабый ветер"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "fi":			
			if (obj.windspeed >= 118) { var winddesc = "hirmumyrskyn tuulen"; }
			if (obj.windspeed < 118) { var winddesc = "raju tuulenpuuska"; }
			if (obj.windspeed < 103){ var winddesc = "voimakas tuuli"; }
			if (obj.windspeed < 89){ var winddesc = "voimakas myrsky"; }				
			if (obj.windspeed < 75){ var winddesc = "tuore Gale"; }
			if (obj.windspeed < 62) { var winddesc = "kova tuuli"; }
			if (obj.windspeed < 50) { var winddesc = "voimakas tuuli"; }
			if (obj.windspeed < 39) { var winddesc = "Raikkaan"; }
			if (obj.windspeed < 29) { var winddesc = "Kova tuuli"; }	
			if (obj.windspeed < 20) { var winddesc = "lempeä tuuli"; }
			if (obj.windspeed < 12) { var winddesc = "Heikkoa tuulta"; }
			if (obj.windspeed < 6) { var winddesc = "Vaisto"; }
			if (obj.windspeed < 1) { var winddesc = "vähän tuulta"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "nl":			
			if (obj.windspeed >= 118) { var winddesc = "orkaankracht wind"; }
			if (obj.windspeed < 118) { var winddesc = "hevige wind"; }
			if (obj.windspeed < 103){ var winddesc = "sterke wind"; }
			if (obj.windspeed < 89){ var winddesc = "sterke storm"; }				
			if (obj.windspeed < 75){ var winddesc = "verse gale"; }
			if (obj.windspeed < 62) { var winddesc = "harde wind"; }
			if (obj.windspeed < 50) { var winddesc = "sterke wind"; }
			if (obj.windspeed < 39) { var winddesc = "frisse wind"; }
			if (obj.windspeed < 29) { var winddesc = "matige wind"; }	
			if (obj.windspeed < 20) { var winddesc = "zwakke wind"; }
			if (obj.windspeed < 12) { var winddesc = "lichte bries"; }
			if (obj.windspeed < 6) { var winddesc = "zwak"; }
			if (obj.windspeed < 1) { var winddesc = "little wind"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "ge":
			if (obj.windspeed >= 118) { var winddesc = "orkanartigen Wind"; }
			if (obj.windspeed < 118) { var winddesc = "heftiger Wind"; }
			if (obj.windspeed < 103){ var winddesc = "starker Wind"; }
			if (obj.windspeed < 89){ var winddesc = "starken Sturm"; }				
			if (obj.windspeed < 75){ var winddesc = "frischen Sturm"; }
			if (obj.windspeed < 62) { var winddesc = "hohen Wind"; }
			if (obj.windspeed < 50) { var winddesc = "starke Brise"; }
			if (obj.windspeed < 39) { var winddesc = "frische Brise"; }
			if (obj.windspeed < 29) { var winddesc = "Sanfte Brise"; }	
			if (obj.windspeed < 20) { var winddesc = "Leichte Brise"; }
			if (obj.windspeed < 12) { var winddesc = "leichte Brise"; }
			if (obj.windspeed < 6) { var winddesc = "Licht Luft"; }
			if (obj.windspeed < 1) { var winddesc = "wenig Wind"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "sp":
			if (obj.windspeed >= 118) { var winddesc = "viento huracanado"; }
			if (obj.windspeed < 118) { var winddesc = "viento violento"; }
			if (obj.windspeed < 103){ var winddesc = "viento fuerte"; }
			if (obj.windspeed < 89){ var winddesc = "ventarron fuerte"; }				
			if (obj.windspeed < 75){ var winddesc = "ventarron fresco"; }
			if (obj.windspeed < 62) { var winddesc = "viento fuerte"; }
			if (obj.windspeed < 50) { var winddesc = "brisa fuerte"; }
			if (obj.windspeed < 39) { var winddesc = "brisa fresca"; }
			if (obj.windspeed < 29) { var winddesc = "brisa moderada"; }	
			if (obj.windspeed < 20) { var winddesc = "brisa normal"; }
			if (obj.windspeed < 12) { var winddesc = "brisa"; }
			if (obj.windspeed < 6) { var winddesc = "viento suave"; }
			if (obj.windspeed < 1) { var winddesc = "viento"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "it":
			if (obj.windspeed >= 118) { var winddesc = "uragano-forza del vento"; }
			if (obj.windspeed < 118) { var winddesc = "vento violento"; }
			if (obj.windspeed < 103){ var winddesc = "forte vento"; }
			if (obj.windspeed < 89){ var winddesc = "forte vento"; }				
			if (obj.windspeed < 75){ var winddesc = "vento fresco "; }
			if (obj.windspeed < 62) { var winddesc = "forte vento"; }
			if (obj.windspeed < 50) { var winddesc = "vento forte"; }
			if (obj.windspeed < 39) { var winddesc = "fresca brezza"; }
			if (obj.windspeed < 29) { var winddesc = "brezza moderata"; }	
			if (obj.windspeed < 20) { var winddesc = "brezza leggera"; }
			if (obj.windspeed < 12) { var winddesc = "brezza leggera"; }
			if (obj.windspeed < 6) { var winddesc = "vento leggero"; }
			if (obj.windspeed < 1) { var winddesc = "po di vento"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "tr": 
			if (obj.windspeed >= 118) { var winddesc = "kasırga"; }
			if (obj.windspeed <118) { var winddesc = "şiddetli rüzgar"; } 
			if (obj.windspeed <103) { var winddesc = "kuvvetli rüzgar"; } 
			if (obj.windspeed <89) { var winddesc = "güçlü fırtına"; } 
			if (obj.windspeed <75) { var winddesc = "güçlü meltem"; } 
			if (obj.windspeed <62) { var winddesc = "yüksek rüzgar"; } 
			if (obj.windspeed <50) { var winddesc = "güçlü esinti"; } 
			if (obj.windspeed <39) { var winddesc = "taze esinti"; } 
			if (obj.windspeed <29) { var winddesc = "ılımlı esinti"; } 
			if (obj.windspeed <20) { var winddesc = "nazik esinti"; } 
			if (obj.windspeed <12) { var winddesc = "hafif esinti"; } 
			if (obj.windspeed <6) { var winddesc = "hafif rüzgar"; } 
			if (obj.windspeed <1) { var winddesc = "az rüzgar"; } 
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		case "gr":
			if (obj.windspeed >= 118) { var winddesc = "Τύφωνας"; }
			if (obj.windspeed < 118) { var winddesc = "Ισχυροί Άνεμοι"; }
			if (obj.windspeed < 103){ var winddesc = "Ενισχυμένοι Άνεμοι"; }
			if (obj.windspeed < 89){ var winddesc = "Ισχυροι Θυελλώδης Άνεμοι"; }				
			if (obj.windspeed < 75){ var winddesc = "Θυελλώδης Άνεμος"; }
			if (obj.windspeed < 62) { var winddesc = "Ισχυρός Άνεμος"; }
			if (obj.windspeed < 50) { var winddesc = "Δυνατός Αέρας"; }
			if (obj.windspeed < 39) { var winddesc = "Πολύς Αέρας"; }
			if (obj.windspeed < 29) { var winddesc = "Αρκετός Αέρας"; }	
			if (obj.windspeed < 20) { var winddesc = "Μετριος Αέρας"; }
			if (obj.windspeed < 12) { var winddesc = "Ήπιος Αέρας"; }
			if (obj.windspeed < 6) { var winddesc = "Ελαφρύς Αέρας"; }
			if (obj.windspeed < 1) { var winddesc = "Λίγος Αέρας"; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		default:			
			if (obj.windspeed >= 118) { var winddesc = "hurricane-force wind."; }
			if (obj.windspeed < 118) { var winddesc = "violent wind."; }
			if (obj.windspeed < 103){ var winddesc = "strong wind."; }
			if (obj.windspeed < 89){ var winddesc = "strong gale."; }				
			if (obj.windspeed < 75){ var winddesc = "fresh gale."; }
			if (obj.windspeed < 62) { var winddesc = "high wind."; }
			if (obj.windspeed < 50) { var winddesc = "strong breeze."; }
			if (obj.windspeed < 39) { var winddesc = "fresh breeze."; }
			if (obj.windspeed < 29) { var winddesc = "moderate breeze."; }	
			if (obj.windspeed < 20) { var winddesc = "gentle breeze."; }
			if (obj.windspeed < 12) { var winddesc = "light breeze."; }
			if (obj.windspeed < 6) { var winddesc = "light air."; }
			if (obj.windspeed < 1) { var winddesc = "little wind."; }
			if (obj.windspeed == 0) { var winddesc = ""; }
			return winddesc;
		break;
		}
}