/* ------ WW2_Modders_Base_Widget (simple widget) By Ian Nicoll ------ */

/*  LANGUAGES: */
var lang = "en"; // en English, fr French, ge German, it Italian, sp Spanish, nl Dutch, fi Finland, no Norweigan, tr Turkish, gr Greek, ru Russian, cn Chinese.

var GoogleBackup = false; //BackUp city names - true for Google, false for Yahoo (only activates when WW2 API is down).
var Wallpaper_options = "none"; // weatherWalls, user or none.
var useDoubleTap = true; // true or false
var showClock = true; // true or false
var SecDisplay = false; // true or false
var showDate = true; // true or false
var numberOfForcastDays = "3"; // 1 TO 5, AFTER YOU CHANGE YOU NEED TO REPOSITION IN CSS: #forecastContainer
var iconSetForForecast = "cocco"; // cocco,HTC or YahooWithShadow.
var iconSetForCurrentCondition = "cocco"; // HTC or YahooWithShadow.
var UseExtraLocation = "neighborhood"; // city or neighborhood (used for cityname).
var Show_Wind_Description = false; // true to show wind description after city name.
var Hi_Lo_Reversed = false; // Hi temp's first in the forecast.
var WindArrow_Shows_Direction_Wind_Is_Blowing =true; // false, & it will point to direction wind is comming from.
var ShowAddress = false;  //true to display street address