/*
Code by Dacal - Modded by iPhoneiHelper (Paarth)
*/
if (screen.height > 500) {var iPhoneType = "iphone5"; } else {var iPhoneType = "iphone4"; }

if (iPhoneType == "iphone4") { replacejscssfile("Main", "i5paarth", "i4paarth", "css"); }

function loadjscssfile(url, filename, filetype) {
    if (filetype == "css") {
        fileref = document.createElement("link");
        fileref.rel = "stylesheet";
        fileref.href = "Css/" + url + "/" + filename + ".css";
        fileref.type = "text/css";
        fileref.media = "screen";
    }
    document.getElementsByTagName("head")[0].appendChild(fileref);
}

function createjscssfile(url, filename, filetype) {
    if (filetype == "css") {
        fileref = document.createElement("link");
        fileref.rel = "stylesheet";
        fileref.href = "Css/" + url + "/" + filename + ".css";
        fileref.type = "text/css";
        fileref.media = "screen";
    }
    return fileref;
}

function replacejscssfile(url, oldfilename, newfilename, filetype){
	var targetelement = (filetype=="css")? "link" : "none";
	var targetattr = (filetype=="css")? "href" : "none";
	var allsuspects = document.getElementsByTagName(targetelement);
	for (var i = allsuspects.length; i>=0; i--) { 
			if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
				var newelement = createjscssfile(url, newfilename, filetype);
				allsuspects[i].parentNode.replaceChild(newelement, allsuspects[i]);
				}
		}
}

function removejscssfile(url, oldfilename, filetype) {
    var targetelement, targetattr, allsuspects;
    targetelement = (filetype == "css") ? "link" : "none";
    targetattr = (filetype == "css") ? "href" : "none";
    allsuspects = document.getElementsByTagName(targetelement);
    for (var i = allsuspects.length; i>=0; i--) {
        if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(oldfilename)!=-1) {
        allsuspects[i].parentNode.removeChild(allsuspects[i]);
        }
    }
}