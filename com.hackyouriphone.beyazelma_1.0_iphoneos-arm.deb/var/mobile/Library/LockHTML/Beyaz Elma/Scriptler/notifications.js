window.addEventListener("load", function() {
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#crown,#L1,#L2,#month,#Cal,#dots,#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
    } else {
        $('#crown,#L1,#L2,#month,#Cal,#dots,#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
    }

    setTimeout(notif, 1000);
};

notif();
