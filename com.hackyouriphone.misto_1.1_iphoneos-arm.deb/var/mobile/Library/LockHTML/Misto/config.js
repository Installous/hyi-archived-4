var MainColor = "Black";
var TimeColor = "linear-gradient(to top, #ff512f, #dd2476)";
var DarkIcon = true;
var ZoomLevel = 80;