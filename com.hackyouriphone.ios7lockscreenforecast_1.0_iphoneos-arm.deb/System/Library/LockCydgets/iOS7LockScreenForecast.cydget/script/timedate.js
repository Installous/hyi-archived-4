/*
                                                                                
                                                                        M~M.    
                                MMM.            MM.                    MM.M     
                      .MM      MMMM           MMMMMM                 IMMMMM     
      MM~             .MNMMM           M        MM             MMM     MM       
     MM MMM.           MM .M=   MM    MM MM.    MM            MM :M,   MM       
    MM. ZMM M.        :MD .MM   MM M. MMMMM  M.+MM .M         MM  MM   MM       
    MM  MM? M         ?MM MM    M$.M  MMMMM N. ~M$.M         .MM  M    MM       
    MM  MMMM          DMMMM.    MMM   MM .MM    MMM+          .MMM    .MM       
     MMM              MM                        ~M.                    MM       
                      MM                                                        
                                                                                
     .      .     .           ..         .   ..               ..    ..    ..    
    MMMMMMMMM.  .MMMMMMMMM   .MMMMMM7   DMMMMM,           MMMMMM   .MMMMMMM.    
    MMMMMMMMM.  MMMMMMMMMM   .MM  MM,   DMMMMM,           MMMMMM  ~MMMMMMM      
    MMMMMMMMMM  MMMMMMMMMM   $M.  ,MM   DMMMMM,           MMMMMM MMMMMMMM       
    MMMMMMMMMM. MMMMMMMMMM  .MMMMMMNM   DMMMMM,           MMMMMMMMMMMMMM        
    MMMMMMMMMMMMMMMMMMMMMM  NM MMMMMMM  DMMMMM,           MMMMMMMMMMMMM.        
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMMM  DMMMMM,           MMMMMMMMMMMI          
    MMMMMMMMMMMMMMMMMMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMM.          
    MMMMMMDMMMMMMMM.MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMM,         
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM,           MMMMMMMMMMMMM~        
    MMMMMM MMMMMMMM MMMMMM  MMMMMMMMIM  DMMMMM~           MMMMMMMMMMMMMM,       
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM   MMMMMM  MMMMMMM=      
    MMMMMM  MMMMMM  MMMMMM  MMMMMMMMIM  DMMMMMMMMMMMMMM.  MMMMMM   MMMMMMM$     
    MMMMMM  MMMMM   MMMMMM  MMZ77777MM. DMMMMMMMMMMMMMM.  MMMMMM    MMMMMMMN    
     MMMM   ,DMM=   7MMMM.  .?MMMMMMM    MMMMMMMMMMMMM    =MMMM.    .$MMMMM.    

Thank you for purchasing this 'iOS 7 LockScreen Forecast' Cydget theme. Whilst
we can not prevent you stealing this code, redistributing it or giving it to
your mates. We would appreciate you actually purchased it from the Cydia
store. This way, we can devote time to supporting, upgrading and adding
additional features. If you have stolen this script, please either purchase
it from the Cydia store or buy us a coffee. PayPal: payment@apintofmilk.com.

This is version 1.0
Support at: http://themes.apintofmilk.com/support/
                                                                                
*/
                                                                                
function updateClock(){var e=new Date;var t=e.getHours();var n=e.getMinutes();var r=e.getSeconds();if(milkHours=="1"){if(t<10){t="0"+t}}else{if(t>12){t=t-12}}if(n<10){n="0"+n}if(r<10){r="0"+r}var i=document.getElementById("clock");i.innerHTML="<p>"+t+":"+n+"</p>"}function getCalendarDate(){var e=new Array;e[0]="January";e[1]="February";e[2]="March";e[3]="April";e[4]="May";e[5]="June";e[6]="July";e[7]="August";e[8]="September";e[9]="October";e[10]="November";e[11]="December";var t=new Array(7);t[0]="Sunday";t[1]="Monday";t[2]="Tuesday";t[3]="Wednesday";t[4]="Thursday";t[5]="Friday";t[6]="Saturday";var n=new Date;var r=n.getMonth();var i=e[r];var s=n.getDate();var o=n.getDay();var u=t[o];var a=n.getYear();if(a<2e3){a=a+1900}var f=document.getElementById("date");f.innerHTML="<p>"+u+"</p><p>"+s+" "+i+"</p>"}setInterval("updateClock()",100);setInterval("getCalendarDate()",100);