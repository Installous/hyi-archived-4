var Clock = "12h"; // choose between "12h" or "24h"
/* SCREEN SIZE */
var iPhoneType = "auto"; // "auto", iPh5", "iPh6" or "iPh6Plus".
var lang = "en"; // (fr) for french, (de) for german, (sp) for spanish, (it) for italian, (en) for english
var gps = false; // Requires MyLocation app
var locale = 2459115; // Yahoo Weather (used if gps set to false or myLocation.txt file not found)
var tempUnit = "c"; // f for fahrenheit
var iconSet = "stardock"; // add your own set
var updateInterval = 60; // in minutes
var UseCityGPS = false; // If your city is innacurate with Yahoo, you can try to use the GPS localization (if available).
var UseNeighborhood = false; // If your city is inaccurate with GPS localization, you can try to use the neighborhood (or state).
