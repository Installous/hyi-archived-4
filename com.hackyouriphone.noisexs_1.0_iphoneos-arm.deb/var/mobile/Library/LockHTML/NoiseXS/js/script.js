var canvas, gl, shaderProgram, vertexBuffer;
var timeLoc, animTime = 0, delta, lastTime = Date.now();

loadShader = (type, id) => {
	var source = document.getElementById(id).innerHTML, shader = gl.createShader(type);
	gl.shaderSource(shader, source);
	gl.compileShader(shader);
	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
		gl.deleteShader(shader);
	}
	return shader;
}

initShaderProgram = () => {
	var fragmentShader = loadShader(gl.FRAGMENT_SHADER, 'shader-fs'), vertexShader = loadShader(gl.VERTEX_SHADER, 'shader-vs');
	shaderProgram = gl.createProgram();
	gl.attachShader(shaderProgram, vertexShader);
	gl.attachShader(shaderProgram, fragmentShader);
	gl.linkProgram(shaderProgram);
	sWidth = gl.getUniformLocation(shaderProgram, "uScreenWidth");
	sHeight = gl.getUniformLocation(shaderProgram, "uScreenHeight");
	timeLoc = gl.getUniformLocation(shaderProgram, "time");
	gl.useProgram(shaderProgram);
	gl.enableVertexAttribArray(0);
}

initBuffers = () => {
	vertexBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
	var triangleVertices = [-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 0.0, 1.0, -1.0, -1.0,-1.0, -1.0, 0.0, 1.0, 1.0, 1.0];
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(triangleVertices), gl.STATIC_DRAW);
	vertexBuffer.itemSize = 3; vertexBuffer.numberOfItems = 6;
}

draw = () => {
	gl.clear(gl.COLOR_BUFFER_BIT);
	gl.vertexAttribPointer(0, vertexBuffer.itemSize, gl.FLOAT, false, 0, 0);
	var time = Date.now();
	delta = time - lastTime; 
	lastTime = time;
	animTime += delta;
	gl.uniform1f(sWidth, window.innerWidth);
	gl.uniform1f(sHeight, window.innerHeight);
	gl.uniform1f(timeLoc, (Math.sin(animTime / 300) + 1) / 2);
	gl.drawArrays(gl.TRIANGLES, 0, vertexBuffer.numberOfItems);
	requestAnimationFrame(draw);
}

window.onload = () => {
	canvas = document.getElementById("canvas3D");
	gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
	gl.viewportWidth = canvas.width = window.innerWidth; 
	gl.viewportHeight = canvas.height = window.innerHeight;
	gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
	gl.depthFunc(gl.LEQUAL);
	gl.enable(gl.DEPTH_TEST);
	gl.enable(gl.BLEND);
	gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
	initShaderProgram();
	initBuffers();
	gl.clearColor(0.3, 0.6, 0.3, 1.0);
	draw();
}