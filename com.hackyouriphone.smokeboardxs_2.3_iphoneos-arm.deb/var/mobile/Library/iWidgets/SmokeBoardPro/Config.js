var SResolution = "128"; // Configure style: 32, 64, 128 or 256. Default is 128. Try lowering this if you experience issues on older devices.
var SplatRadius = "0.4"; // Configure the splat radius between 0.1 and 0.9. Default is 0.5
var EnableBloom = false; // Enables the bloom effect to the smoke!
var SetRandomColors = true; // Toggle color randomization while touched on or off!
var Credits = "💜"; // Credits go to @PavelDoGreat
