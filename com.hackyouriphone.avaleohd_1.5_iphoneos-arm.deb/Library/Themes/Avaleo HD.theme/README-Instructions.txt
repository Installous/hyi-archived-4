Instructions for using Avaleo HD theme for iPhone 4 by Primo.

1. Requirements

	- WinterBoard
	- ***Gridlock (only if you want to use the included Weather widget)
	- ***ColorKeyboard (only if you want to use the included ColorKeyboard theme)
	
	
2. Installation

	- Copy folders "Avaleo HD.theme", "Avaleo HD-Lockscreen.theme" and "Avaleo HD-Widget(1).theme" to "/Library/Themes/" on your device and activate through WinterBoard (make sure "SummerBoard Mode" is "ON")
	- Copy SetAsWallpaper.png (from "Avaleo HD.theme" folder) to your pictures folder and set it as home and lockscreen wallpaper.
	- If you want to use the SBSettings theme, go to folder "SBSettings/" and copy folder "AvaleoHD" to "/var/mobile/Library/SBSettings/Themes/" on your device and activate the theme in SBSettings
	- If you want to use the ColorKeyboard theme, go to folder "ColorKeyboard/" and copy folder "AvaleoHD" to "/Library/ColorKeyboard/Themes/" on your device and activate the theme in ColorKeyboard
	
3. Configuration

	- Weather widget - open "/Library/Themes/Avaleo HD-Widget(1).theme/configureMe.js" with any text editor and edit whatever you need. RESPRING the device for changes to take effect!
	- How to find your location code:
		- Open http://weather.yahoo.com , find your location and click on it;
		- Click on the "RSS" link on the right and look at the browser's address bar. It should say something like "http://weather.yahooapis.com/forecastrss?p=UKXX0085&u=f". The code "UKXX0085" at the end is the location code.
  
	*For LockScreen:
	- If you want Sunday to be first day of week, open LockBackground.html in "Avaleo HD-Lockscreen.theme" folder, find "var Calendar_starts_on_Monday = true;" and change to "false".

 	- PSD files for icons are included in "PSD" folder
	
	
4. Support

	- Official ModMyi thread: 
	  http://modmyi.com/forums/iphone-4-new-skins-themes-launches/801630-avaleo-hd-theme-release.html
	  
	- You can also get support by following me on Twitter: www.twitter.com/PrimoTM
	  
	- If you have any suggestions for new icons, UI elements, or anything else, you can post them in the thread.