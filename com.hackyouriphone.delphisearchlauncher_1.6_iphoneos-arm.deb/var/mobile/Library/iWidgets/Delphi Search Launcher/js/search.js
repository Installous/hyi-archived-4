
function enterKey(key){
  var val;
  window.event?val = window.event.keyCode:key && (val=key.which);
  13 == val && openLink();
}

function closeSearch(){
  doc.getElementById("searchBar").className = "hideSearch";
  setTimeout( function() {
    doc.getElementById("pixelSection").className = "showPixel";
    if(sideWrapper === "date"){
      doc.getElementById("dateWrapper").className = "showDate";
    }else if(sideWrapper === "weather"){
      doc.getElementById("wxWrapper").className = "showWx";
    }
  }, 500 );
  doc.getElementById("search").blur();
}

function openSearch(){
  doc.getElementById("pixelSection").className = "hidePixel";
  if(sideWrapper === "date"){
    doc.getElementById("dateWrapper").className = "hideDate";
  }else if(sideWrapper === "weather"){
    doc.getElementById("wxWrapper").className = "hideWx";
  }
  setTimeout( function() {
    doc.getElementById("searchBar").className = "showSearch";
  }, 500 );
  doc.getElementById("search").focus();
}

function openLink(){
  closeSearch();
  var search = doc.getElementById("search");
  var term = search.value;
  term = encodeURIComponent(term);
  var link = doc.getElementById("browser");
  if(favBrowser === "googlechrome"){
    link.href = "googlechrome://www.google.com/search?q=" + term;
  }else{
    link.href = "http://www.google.com/search?q=" + term;
  }
  setTimeout(function(){
    search.value = "";
  },5000);
  openBrowser(link.href);
}

function showDate() {
  doc.getElementById("wxWrapper").className = "hideWx";
  setTimeout( function() {
    doc.getElementById("dateWrapper").className = "showDate";
  }, 500 );
  sideWrapper = "date";
}

function showWx() {
  doc.getElementById("dateWrapper").className = "hideDate";
  setTimeout( function() {
    doc.getElementById("wxWrapper").className = "showWx";
  }, 500 );
  sideWrapper = "weather";
}
